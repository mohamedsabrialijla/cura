<?php

namespace App\Providers;

use App\Http\Middleware\AuthenticateAdmin;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\URL;



class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
            Schema::defaultStringLength(191);
            URL::forceRootUrl(config('app.url'));

            $router = $this->app->make('router');
            if (method_exists($router, 'aliasMiddleware')) {
                $router->aliasMiddleware('auth.admin', AuthenticateAdmin::class);
            }

            // if (app()->environment('local')) {
            //     URL::forceScheme('https');
            // }

    }
}

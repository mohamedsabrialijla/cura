<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'required' => 'حقل :attribute مطلوب.',
    'min' => 'يجب أن يكون :attribute على الأقل :min حروف.',
    'confirmed' => 'تأكيد :attribute لا يتطابق.',
    'password.regex' => 'يجب أن تحتوي كلمة المرور على رمز واحد على الأقل.',

    'accepted'             => 'يجب قبول الحقل :attribute',
    'active_url'           => 'الحقل :attribute لا يُمثّل رابطًا صحيحًا',
    'after'                => 'يجب على الحقل :attribute أن يكون تاريخًا لاحقًا للتاريخ :date.',
    'after_or_equal'       => 'The :attribute must be a date after or equal to :date.',
    'alpha'                => 'يجب أن لا يحتوي الحقل :attribute سوى على حروف',
    'alpha_dash'           => 'يجب أن لا يحتوي الحقل :attribute على حروف، أرقام ومطّات.',
    'alpha_num'            => 'يجب أن يحتوي :attribute على حروفٍ وأرقامٍ فقط',
    'array'                => 'يجب أن يكون الحقل :attribute ًمصفوفة',
    'before'               => 'يجب على الحقل :attribute أن يكون تاريخًا سابقًا للتاريخ :date.',
    'before_or_equal'      => 'The :attribute must be a date before or equal to :date.',
    'between'              => [
        'numeric' => 'يجب أن تكون قيمة :attribute محصورة ما بين :min و :max.',
        'file'    => 'يجب أن يكون حجم الملف :attribute محصورًا ما بين :min و :max كيلوبايت.',
        'string'  => 'يجب أن يكون عدد حروف النّص :attribute محصورًا ما بين :min و :max',
        'array'   => 'يجب أن يحتوي :attribute على عدد من العناصر محصورًا ما بين :min و :max',
    ],
    'boolean'              => 'يجب أن تكون قيمة الحقل :attribute إما true أو false ',
    'confirmed'            => 'حقل التأكيد غير مُطابق للحقل :attribute',
    'date'                 => 'الحقل :attribute ليس تاريخًا صحيحًا',
    'date_format'          => 'لا يتوافق الحقل :attribute مع الشكل :format.',
    'different'            => 'يجب أن يكون الحقلان :attribute و :other مُختلفان',
    'digits'               => 'يجب أن يحتوي الحقل :attribute على :digits رقمًا/أرقام',
    'digits_between'       => 'يجب أن يحتوي الحقل :attribute ما بين :min و :max رقمًا/أرقام ',
    'dimensions'           => 'The :attribute has invalid image dimensions.',
    'distinct'             => 'للحقل :attribute قيمة مُكرّرة.',
    'email'                => 'يجب أن يكون :attribute عنوان بريد إلكتروني صحيح البُنية',
    'exists'               => 'الحقل :attribute غير موجود ضمن السجلات',
    'file'                 => 'The :attribute must be a file.',
    'filled'               => 'الحقل :attribute إجباري',
    'image'                => 'يجب أن يكون الحقل :attribute صورةً',
    'in'                   => 'الحقل :attribute غير موجود ضمن السجلات',
    'in_array'             => 'الحقل :attribute غير موجود في :other.',
    'integer'              => 'يجب أن يكون الحقل :attribute عددًا صحيحًا',
    'ip'                   => 'يجب أن يكون الحقل :attribute عنوان IP ذي بُنية صحيحة',
    'ipv4'                 => 'The :attribute must be a valid IPv4 address.',
    'ipv6'                 => 'The :attribute must be a valid IPv6 address.',
    'json'                 => 'يجب أن يكون الحقل :attribute نصآ من نوع JSON.',
    'max'                  => [
        'numeric' => 'يجب أن تكون قيمة الحقل :attribute أصغر من :max.',
        'file'    => 'يجب أن يكون حجم الملف :attribute أصغر من :max كيلوبايت',
        'string'  => 'يجب أن لا يتجاوز طول النّص :attribute :max حروفٍ/حرفًا',
        'array'   => 'يجب أن لا يحتوي الحقل :attribute على أكثر من :max عناصر/عنصر.',
    ],
    'mimes'                => 'يجب أن يكون الحقل ملفًا من نوع : :values.',
    'min'                  => [
        'numeric' => 'يجب أن تكون قيمة الحقل :attribute أكبر من :min.',
        'file'    => 'يجب أن يكون حجم الملف :attribute أكبر من :min كيلوبايت',
        'string'  => 'يجب أن يكون طول النص :attribute أكبر من :min حروفٍ/حرفًا',
        'array'   => 'يجب أن يحتوي الحقل :attribute على الأقل على :min عُنصرًا/عناصر',
    ],
    'not_in'               => 'الحقل :attribute غير موجود ضمن السجلات',
    'numeric'              => 'يجب على الحقل :attribute أن يكون رقمًا',
    'present'              => 'The :attribute field must be present.',
    'regex'                => 'صيغة الحقل :attribute .غير صحيحة',
    'required'             => 'الحقل :attribute مطلوب.',
    'required_if'          => 'الحقل :attribute مطلوب في حال ما إذا كان :other يساوي :value.',
    'required_unless'      => 'الحقل :attribute مطلوب في حال ما لم يكن :other يساوي :values.',
    'required_with'        => 'الحقل :attribute إذا توفّر :values.',
    'required_with_all'    => 'الحقل :attribute إذا توفّر :values.',
    'required_without'     => 'الحقل :attribute إذا لم يتوفّر :values.',
    'required_without_all' => 'الحقل :attribute إذا لم يتوفّر :values.',
    'same'                 => 'يجب أن يتطابق الحقل :attribute مع :other',
    'size'                 => [
        'numeric' => 'يجب أن تكون قيمة :attribute أكبر من :size.',
        'file'    => 'يجب أن يكون حجم الملف :attribute أكبر من :size كيلو بايت.',
        'string'  => 'يجب أن يحتوي النص :attribute عن ما لا يقل عن  :size حرفٍ/أحرف.',
        'array'   => 'يجب أن يحتوي الحقل :attribute عن ما لا يقل عن:min عنصرٍ/عناصر',
    ],
    'string'               => 'يجب أن يكون الحقل :attribute نصآ.',
    'timezone'             => 'يجب أن يكون :attribute نطاقًا زمنيًا صحيحًا',
    'unique'               => 'قيمة الحقل :attribute مُستخدمة من قبل',
    'url'                  => 'صيغة الرابط :attribute غير صحيحة',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
        'attribute-name' => [
            'rule-name' => 'custom-message',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap attribute place-holders
    | with something more reader friendly such as E-Mail Address instead
    | of "email". This simply helps us make messages a little cleaner.
    |
    */

    'attributes' => [

        'backend' => [
            'access' => [
                'permissions' => [
                    'associated_roles' => 'الأدوار المرفقة',
                    'dependencies'     => 'المتعلقات',
                    'display_name'     => 'إسم العرض',
                    'group'            => 'المجموعة',
                    'group_sort'       => 'ترتيب المجموعة',

                    'groups' => [
                        'name' => 'إسم المجموعة',
                    ],

                    'name'   => 'الإسم',
                    'system' => 'نظام؟',
                ],

                'roles' => [
                    'associated_permissions' => 'الصلاحيات المرفقة',
                    'name'                   => 'الإسم',
                    'sort'                   => 'الترتيب',
                ],

                'users' => [
                    'active'                  => 'مفعل',
                    'associated_roles'        => 'الأدوار المرفقة',
                    'confirmed'               => 'مؤكد',
                    'email'                   => 'عنوان البريد الإلكتروني',
                    'name'                    => 'الإسم',
                    'other_permissions'       => 'الصلاحيات الأخرى',
                    'password'                => 'كلمة المرور',
                    'password_confirmation'   => 'تأكيد كلمة المرور',
                    'send_confirmation_email' => 'إرسال رسالة التفعيل',
                ],
            ],
        ],

        'frontend' => [
            'email'                     => 'عنوان البريد الإلكتروني',
            'name'                      => 'الإسم',
            'password'                  => 'كلمة المرور',
            'password_confirmation'     => 'تأكيد كلمة المرور',
            'phone' => 'Phone',
            'message' => 'Message',
            'old_password'              => 'كلمة المرور القديمة',
            'new_password'              => 'كلمة المرور الجديدة',
            'new_password_confirmation' => 'تأكيد كلمة المرور الجديدة',
        ],
    ],




    'name' => [
        'required' => 'الاسم مطلوب',
        'string'   => 'الاسم يجب أن يكون نصاً',
        'min'      => 'الاسم يجب أن يكون على الأقل :min أحرف',
        'max'      => 'الاسم يجب ألا يزيد عن :max أحرف',
    ],
    'email' => [
        'required' => 'البريد الإلكتروني مطلوب',
        'email'    => 'صيغة البريد الإلكتروني غير صحيحة',
        'unique'   => 'هذا البريد الإلكتروني مسجل بالفعل',
    ],
    'mobile' => [
        'required' => 'رقم الجوال مطلوب',
        'string'   => 'رقم الجوال يجب أن يكون نصياً',
        'min'      => 'رقم الجوال يجب أن لا يقل عن :min أرقام',
        'max'      => 'رقم الجوال يجب ألا يزيد عن :max أرقام',
        'unique'   => 'رقم الجوال مسجل بالفعل',
    ],
    'gender' => [
        'required' => 'النوع مطلوب',
        'in'       => 'النوع يجب أن يكون ذكر أو أنثى',
    ],
    'country_id' => [
        'required' => 'الدولة مطلوبة',
        'exists'   => 'الدولة المختارة غير صحيحة',
    ],
    'city_id' => [
        'required' => 'المدينة مطلوبة',
        'exists'   => 'المدينة المختارة غير صحيحة',
    ],
    'password' => [
        'min' => 'كلمة المرور يجب أن لا تقل عن :min أحرف',
    ],
    'confirmPassword' => [
        'same' => 'تأكيد كلمة المرور لا يطابق كلمة المرور',
    ],
    'logo' => [
        'file'  => 'الملف يجب أن يكون صورة',
        'mimes' => 'الصورة يجب أن تكون من نوع: jpeg, png, jpg',
        'max'   => 'حجم الصورة يجب ألا يتجاوز 2 ميجابايت',
    ],

];

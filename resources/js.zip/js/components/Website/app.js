import "../../bootstrap";
import "../../axiosUser";

import "../../styles/keepersport-brand.css";

import { createApp } from "vue";
import Router from "../../routes.js";
import store from "../../storeUser.js";

import App from "./layout/App.vue";
import { applyDesktopSiteViewportFix } from "../../utils/desktopSiteViewport.js";

import HeaderWebsite from "./layout/Header.vue";
import FooterWebsite from "./layout/Footer.vue";

applyDesktopSiteViewportFix();

const app = createApp(App);

app.component("headerWebsite", HeaderWebsite);
app.component("footerWebsite", FooterWebsite);

const savedLocale = localStorage.getItem("locale") || window.defaultLocale || "en";

store.dispatch("loadTranslations", savedLocale).then(() => {
    // ضبط اتجاه الصفحة
    if (savedLocale === "ar") {
        document.documentElement.setAttribute("dir", "rtl");
        document.documentElement.setAttribute("lang", "ar");
        document.body.classList.add("rtl");
    } else {
        document.documentElement.setAttribute("dir", "ltr");
        document.documentElement.setAttribute("lang", "en");
        document.body.classList.remove("rtl");
    }

    
    app.use(store);

    app.use(Router);

    app.mount("#app");
});

<template>
    <div class="ks-page" :lang="lt.page_lang">
        <!-- Hero cover: shimmer until DB image is fully loaded — never show CDN fallback -->
        <section class="ks-hero-img" :class="{ 'is-hero-ready': heroCoverLoaded && !!heroCoverImageActive }">
            <div
                v-if="showHeroCoverShimmer"
                class="ks-hero-shimmer"
                aria-hidden="true"
            ></div>
            <a
                v-show="heroCoverImageActive"
                class="ks-hero-link-wrap"
                :class="{ 'ks-hero-link-wrap--ready': heroCoverLoaded }"
                :href="heroLinkProps.href"
            >
                <img
                    v-if="heroCoverImageActive"
                    :key="heroCoverImageActive"
                    class="ks-full-img ks-hero-cover-img"
                    :src="heroCoverImageActive"
                    :alt="lt.hero_img_alt"
                    loading="eager"
                    fetchpriority="high"
                    decoding="async"
                    @load="onHeroCoverLoaded"
                    @error="onHeroCoverLoaded"
                />
            </a>
            <div v-if="showHeroCoverText && heroCoverLoaded" class="ks-hero-overlay">
                <h2 class="ks-hero-title">{{ lt.hero_title }}</h2>
                <a
                    class="ks-cta"
                    :href="heroLinkProps.href"
                    >{{ lt.hero_cta }}</a
                >
            </div>
        </section>

        <!-- uhlsport glove strip (under planet hero, like keepersport.it) -->
        <section
            v-if="uhlsportPlanetSliderProducts.length"
            class="ks-planet-product-strip"
            :aria-label="lt.planet_strip_aria"
        >
            <div class="ks-planet-product-box">
                    <button
                        type="button"
                        class="ks-planet-product-arrow ks-planet-product-arrow--prev"
                        :aria-label="lt.scroll_prev"
                        @click="scrollUhlsportPlanetSlider(-1)"
                    >
                        ‹
                    </button>
                    <button
                        type="button"
                        class="ks-planet-product-arrow ks-planet-product-arrow--next"
                        :aria-label="lt.scroll_next"
                        @click="scrollUhlsportPlanetSlider(1)"
                    >
                        ›
                    </button>
                    <div
                        ref="uhlsportPlanetSliderRef"
                        class="ks-planet-product-scroll"
                        tabindex="0"
                    >
                        <router-link
                            v-for="(p, idx) in uhlsportPlanetSliderProducts"
                            :key="idx"
                            class="ks-planet-product-card"
                            :to="p.productPath || `/${siteLocale}/goalkeeper-gloves`"
                            @mouseenter="prefetchLandingProduct(p)"
                            @touchstart.passive="prefetchLandingProduct(p)"
                        >
                            <div class="ks-planet-product-img-wrap">
                                <span
                                    v-if="p.discountPct"
                                    class="ks-planet-product-ribbon"
                                    aria-hidden="true"
                                    >-<span lang="en" dir="ltr">{{ p.discountPct }}%</span></span
                                >
                                <img
                                    :src="p.img"
                                    :alt="p.title"
                                    loading="lazy"
                                    decoding="async"
                                />
                            </div>
                            <p class="ks-planet-product-brand">{{ (p.brand || "").toUpperCase() }}</p>
                            <p class="ks-planet-product-title">{{ p.title }}</p>
                            <div class="ks-planet-product-price">
                                <span
                                    v-if="p.priceWas"
                                    class="ks-planet-product-price-was ks-price-strike"
                                    v-html="p.priceWas"
                                ></span>
                                <span class="ks-planet-product-price-now" v-html="p.priceNow"></span>
                            </div>
                        </router-link>
                    </div>
            </div>
            <div class="ks-planet-product-cta">
                <a
                    class="ks-cta ks-cta--planet-slider"
                    :href="homeSliderCtaProps.href"
                    >{{ lt.planet_slider_cta }}</a
                >
            </div>
        </section>

        <section
            v-if="categorySlides.length"
            class="ks-category-slider-section"
            :aria-label="lt.category_strip_aria"
        >
            <div class="ks-category-slider-box">
                <button
                    type="button"
                    class="ks-category-arrow ks-category-arrow--prev"
                    :aria-label="lt.scroll_prev"
                    @click="scrollCategoryStrip(-1)"
                >
                    ‹
                </button>
                <button
                    type="button"
                    class="ks-category-arrow ks-category-arrow--next"
                    :aria-label="lt.scroll_next"
                    @click="scrollCategoryStrip(1)"
                >
                    ›
                </button>
                <div ref="categoryScrollRef" class="ks-category-scroll" tabindex="0">
                    <div
                        v-for="(cat, idx) in categorySlides"
                        :key="idx"
                        class="ks-category-slide"
                    >
                        <a
                            v-if="cat.external"
                            class="ks-category-slide-link"
                            :href="cat.href"
                        >
                            <img :src="cat.img" :alt="cat.label" loading="lazy" decoding="async" />
                            <span class="ks-category-slide-label">{{ cat.label }}</span>
                        </a>
                        <router-link
                            v-else
                            class="ks-category-slide-link"
                            :to="cat.to"
                        >
                            <img :src="cat.img" :alt="cat.label" loading="lazy" decoding="async" />
                            <span class="ks-category-slide-label">{{ cat.label }}</span>
                        </router-link>
                    </div>
                </div>
            </div>
        </section>

        <!-- DEAL OF THE WEEK / mega sale (layout like keepersport.it tiles row) -->
        <section class="ks-deals">
            <div class="ks-container">
                <div class="ks-deals-grid">
                    <article class="">
                        <a
                            :href="landingCard(0).link || dealOfWeekUrl"
                            class="ks-deal-img-link"
                        >
                            <img
                                class="ks-deal-img"
                                v-if="landingCard(0).image"
                                :src="landingCard(0).image"
                                :alt="lt.deal_week_img_alt"
                                loading="lazy"
                                decoding="async"
                            />
                        </a>
                        <h2 class="text_color">{{ landingCardTitle(0, lt.deal_week_title) }}</h2>
                    </article>
                    <article class="">
                        <a
                            :href="landingCard(1).link || megaSaleUrl"
                            class="ks-deal-img-link"
                        >
                            <img
                                class="ks-deal-img"
                                v-if="landingCard(1).image"
                                :src="landingCard(1).image"
                                :alt="lt.mega_sale_img_alt"
                                loading="lazy"
                                decoding="async"
                            />
                        </a>
                        <h2 class="text_color">{{ landingCardTitle(1, lt.mega_sale_title) }}</h2> 
                    </article>
                </div>
               





        <section class="ks-strip">
            <a
                :href="whiteoutLinkProps.href"
            >
                <picture v-if="whiteoutSectionImageDesktop || whiteoutSectionImageMobile">
                    <source
                        v-if="whiteoutSectionImageMobile"
                        media="(max-width: 1024px)"
                        :srcset="whiteoutSectionImageMobile"
                    />
                    <img
                        class="ks-full-img ks-responsive-banner-img"
                        :src="whiteoutSectionImageActive || whiteoutSectionImageDesktop || whiteoutSectionImageMobile"
                        :alt="lt.whiteout_alt"
                        loading="lazy"
                        decoding="async"
                    />
                </picture>
            </a>
            <div class="ks-strip-cta">
                <a
                    class="ks-cta"
                    :href="whiteoutLinkProps.href"
                    >{{ lt.discover_cta }}</a
                >
            </div>
        </section>

                <!-- <div class="ks-mega-sale-cta">
                    <a
                        class="ks-cta ks-cta--dark"
                        :href="`${base}/shop/selection/it-sale-valore-5eur.html`"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.show_more_cta }}</a
                    >
                </div> -->
            </div>
        </section>

        

        

        

        <!-- latest news adidas / reusch -->
        <section class="ks-news">
            <div class="ks-container ks-news-grid">
                <article class="">
                    <a
                        :href="landingCard(2).link || newsAdidasFallbackUrl"
                    >
                        <img
                            class="ks-news-img"
                            v-if="landingCard(2).image"
                            :src="landingCard(2).image"
                            :alt="lt.news_adidas_img_alt"
                            loading="lazy"
                            decoding="async"
                        />
                    </a>
                    <h2 class="text_color">{{ landingCardTitle(2, lt.news_adidas_title) }}</h2>
                    <!-- <a
                        class="ks-cta"
                        :href="landingCard(2).link || `${base}/guanti-da-portiere?order=newest_first`"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.discover_cta }}</a
                    > -->
                </article>
                <article class="">
                    <a
                        :href="landingCard(3).link || newsReuschFallbackUrl"
                    >
                        <img
                            class="ks-news-img"
                            v-if="landingCard(3).image"
                            :src="landingCard(3).image"
                            :alt="lt.news_reusch_img_alt"
                            loading="lazy"
                            decoding="async"
                        />
                    </a>
                    <h2 class="text_color">{{ landingCardTitle(3, lt.news_reusch_title) }}</h2>
                    <!-- <a
                        class="ks-cta"
                        :href="landingCard(3).link || `${base}/reusch-guanti-da-portiere?order=newest_first`"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.discover_cta }}</a
                    > -->
                </article>
            </div>
        </section>

      

        <!-- banner freddo -->
        <!-- <section class="ks-freddo">
            <img
                class="ks-full-img ks-img-tight"
                :src="m.freddoAbbigliamento"
                :alt="lt.freddo_alt"
                loading="lazy"
                decoding="async"
            />
            <div class="ks-container ks-freddo-inner">
                <p class="ks-freddo-text">
                    <strong>{{ lt.freddo_lead }}</strong>
                </p>
                <a
                    class="ks-cta"
                    :href="shopTechUrl"
                    target="_blank"
                    rel="noopener"
                    >{{ lt.discover_cta }}</a
                >
            </div>
        </section> -->

        <!-- KeeperBattle -->
        <!-- <section class="ks-battle">
            <a
                class="ks-battle-header-link"
                :href="`${base}/zona-portiere/keepitall-blog/keeperbattle-2026-lunica-e-vera-battaglia-fra-portieri.html`"
                target="_blank"
                rel="noopener"
            >
                <img
                    class="ks-full-img ks-battle-header-img"
                    :src="m.keeperBattleHeader"
                    :alt="lt.battle_header_alt"
                    loading="lazy"
                    decoding="async"
                />
            </a>
            <div class="ks-container ks-battle-inner">
                <p v-html="lt.battle_p1_html"></p>
                <p v-html="lt.battle_p2_html"></p>
                <p v-html="lt.battle_p3_html"></p>
                <a
                    class="ks-cta"
                    :href="`${base}/zona-portiere/keepitall-blog/keeperbattle-2026-lunica-e-vera-battaglia-fra-portieri.html`"
                    target="_blank"
                    rel="noopener"
                    >{{ lt.battle_more_cta }}</a
                >
            </div>
        </section> -->

        <hr class="ks-rule" />

        <!-- Teaser tiles (same imagery as keepersport.it) -->
        <!-- <section class="ks-teasers" :aria-label="lt.teasers_aria">
            <div class="ks-container ks-teasers-grid">
                <article class="ks-teaser">
                    <img
                        :src="m.teaserBePro"
                        :alt="lt.teaser_bepro_alt"
                        loading="lazy"
                        decoding="async"
                    />
                    <h3>{{ lt.teaser_bepro_title }}</h3>
                    <hr class="ks-teaser-rule" />
                    <a
                        class="ks-cta"
                        :href="`${base}/servizio-e-aiuto/glove-guide.html`"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.discover_cta }}</a
                    >
                </article>
                <article class="ks-teaser">
                    <img
                        :src="m.teaserCircleOfPros"
                        :alt="lt.teaser_circle_alt"
                        loading="lazy"
                        decoding="async"
                    />
                    <h3>{{ lt.teaser_circle_title }}</h3>
                    <hr class="ks-teaser-rule" />
                    <a
                        class="ks-cta"
                        :href="`${base}/zona-portiere/keepitall-blog/circle-of-pros.html`"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.discover_cta }}</a
                    >
                </article>
                <article class="ks-teaser">
                    <img
                        :src="m.teaserRisparmia"
                        :alt="lt.teaser_save_alt"
                        loading="lazy"
                        decoding="async"
                    />
                    <h3>{{ lt.teaser_save_title }}</h3>
                    <hr class="ks-teaser-rule" />
                    <a
                        class="ks-cta"
                        :href="`${base}/servizio-e-aiuto/newsletter-1.html`"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.teaser_subscribe_cta }}</a
                    >
                </article>
                <article class="ks-teaser">
                    <img
                        :src="m.teaserSocial"
                        :alt="lt.teaser_social_alt"
                        loading="lazy"
                        decoding="async"
                    />
                    <h3>{{ lt.teaser_social_title }}</h3>
                    <hr class="ks-teaser-rule" />
                    <a
                        v-if="teaserSocialHref"
                        class="ks-cta"
                        :href="teaserSocialHref"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.teaser_social_cta }}</a
                    >
                </article>
                <article class="ks-teaser">
                    <img
                        :src="m.teaserCura"
                        :alt="lt.teaser_care_alt"
                        loading="lazy"
                        decoding="async"
                    />
                    <h3>{{ lt.teaser_care_title }}</h3>
                    <hr class="ks-teaser-rule" />
                    <a
                        class="ks-cta"
                        :href="`${base}/servizio-e-aiuto/manutenzione-dei-guanti.html`"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.discover_cta }}</a
                    >
                </article>
                <article class="ks-teaser">
                    <img
                        :src="m.teaserGoalkeeperDay"
                        :alt="lt.teaser_gkd_alt"
                        loading="lazy"
                        decoding="async"
                    />
                    <h3>{{ lt.teaser_gkd_title }}</h3>
                    <hr class="ks-teaser-rule" />
                    <a
                        class="ks-cta"
                        :href="`${base}/keepersport/goalkeeper-day.html`"
                        target="_blank"
                        rel="noopener"
                        >{{ lt.teaser_gkd_cta }}</a
                    >
                </article>
            </div>
        </section> -->

        <!-- Technical apparel — cover + product slider (keepersport.it) -->
        <section class="ks-technic-section" :aria-label="lt.technic_aria">
            <div class="ks-technic-head">
                <h2 class="ks-technic-title">
                    <span class="ks-technic-title-white">{{ technicTitleWhite }}</span>
                    <span class="ks-technic-title-gold">{{ technicTitleGold }}</span>
                </h2>
                <p class="ks-technic-desc">{{ technicDesc }}</p>
            </div>

            <a
                class="ks-technic-cover-link"
                :href="technicCoverLinkProps.href"
            >
                <picture v-if="technicSectionImageDesktop || technicSectionImageMobile">
                    <source
                        v-if="technicSectionImageMobile"
                        media="(max-width: 1024px)"
                        :srcset="technicSectionImageMobile"
                    />
                    <img
                        class="ks-full-img ks-responsive-banner-img"
                        :src="technicSectionImageActive || technicSectionImageDesktop || technicSectionImageMobile"
                        :alt="lt.technic_cover_alt"
                        loading="lazy"
                        decoding="async"
                    />
                </picture>
            </a>

            <section
                v-if="technicSliderCards.length"
                class="ks-planet-product-strip ks-technic-strip"
                :aria-label="lt.technic_strip_aria"
            >
                <div class="ks-planet-product-box">
                    <button
                        type="button"
                        class="ks-planet-product-arrow ks-planet-product-arrow--prev"
                        :aria-label="lt.scroll_prev"
                        @click="scrollTechnicSlider(-1)"
                    >
                        ‹
                    </button>
                    <button
                        type="button"
                        class="ks-planet-product-arrow ks-planet-product-arrow--next"
                        :aria-label="lt.scroll_next"
                        @click="scrollTechnicSlider(1)"
                    >
                        ›
                    </button>
                    <div
                        ref="technicSliderRef"
                        class="ks-planet-product-scroll"
                        tabindex="0"
                    >
                        <router-link
                            v-for="(p, idx) in technicSliderCards"
                            :key="`technic-${idx}-${p.title}`"
                            class="ks-planet-product-card"
                            :to="p.productPath || `/${siteLocale}/goalkeeper-apparel`"
                            @mouseenter="prefetchLandingProduct(p)"
                            @touchstart.passive="prefetchLandingProduct(p)"
                        >
                            <div class="ks-planet-product-img-wrap">
                                <span
                                    v-if="p.discountPct"
                                    class="ks-planet-product-ribbon"
                                    aria-hidden="true"
                                    >-<span lang="en" dir="ltr">{{ p.discountPct }}%</span></span
                                >
                                <img
                                    :src="p.img"
                                    :alt="p.title"
                                    loading="lazy"
                                    decoding="async"
                                />
                            </div>
                            <p class="ks-planet-product-brand">{{ (p.brand || "").toUpperCase() }}</p>
                            <p class="ks-planet-product-title">{{ p.title }}</p>
                            <div class="ks-planet-product-price">
                                <span
                                    v-if="p.priceWas"
                                    class="ks-planet-product-price-was ks-price-strike"
                                    v-html="p.priceWas"
                                ></span>
                                <span class="ks-planet-product-price-now" v-html="p.priceNow"></span>
                            </div>
                        </router-link>
                    </div>
                </div>
            </section>

            <div class="ks-planet-product-cta ks-technic-cta">
                <a
                    class="ks-cta ks-cta--planet-slider"
                    :href="technicSliderCtaProps.href"
                    >{{ lt.technic_slider_cta }}</a
                >
            </div>
        </section>

        <section class="ks-training-section" :aria-label="lt.training_aria">
            <p class="ks-training">{{ lt.training_label }}</p>
            <a
                class="ks-training-link"
                :href="trainingSectionLink"
            >
                <picture v-if="trainingSectionImageDesktop || trainingSectionImageMobile">
                    <source
                        v-if="trainingSectionImageMobile"
                        media="(max-width: 1024px)"
                        :srcset="trainingSectionImageMobile"
                    />
                    <img
                        class="ks-full-img ks-img-tight ks-responsive-banner-img"
                        :src="trainingSectionImageActive || trainingSectionImageDesktop || trainingSectionImageMobile"
                        :alt="lt.training_img_alt"
                        loading="lazy"
                        decoding="async"
                    />
                </picture>
            </a>
        </section>
        <hr class="ks-rule" />

        <section
            v-if="brandSlides.length"
            class="ks-brand-slider"
            :aria-label="lt.brand_strip_aria"
        >
            <div class="ks-brand-slider-box">
                <button
                    type="button"
                    class="ks-brand-arrow ks-brand-arrow--prev"
                    :aria-label="lt.scroll_prev"
                    @click="scrollBrandStrip(-1)"
                >
                    ‹
                </button>
                <button
                    type="button"
                    class="ks-brand-arrow ks-brand-arrow--next"
                    :aria-label="lt.scroll_next"
                    @click="scrollBrandStrip(1)"
                >
                    ›
                </button>
                <div ref="brandScrollRef" class="ks-brand-scroll" tabindex="0">
                    <template v-for="(brand, idx) in brandSlides" :key="brand.id || idx">
                        <a
                            v-if="brand.hasLink && brand.external"
                            class="ks-brand-pill"
                            :href="brand.href"
                        >
                            <img
                                v-if="brand.logo"
                                class="ks-brand-pill-logo"
                                :src="brand.logo"
                                :alt="brand.label"
                                loading="lazy"
                                decoding="async"
                            />
                            <span v-else>{{ brand.label }}</span>
                        </a>
                        <router-link
                            v-else-if="brand.hasLink"
                            class="ks-brand-pill"
                            :to="brand.to"
                        >
                            <img
                                v-if="brand.logo"
                                class="ks-brand-pill-logo"
                                :src="brand.logo"
                                :alt="brand.label"
                                loading="lazy"
                                decoding="async"
                            />
                            <span v-else>{{ brand.label }}</span>
                        </router-link>
                        <div
                            v-else
                            class="ks-brand-pill ks-brand-pill--static"
                            :aria-label="brand.label"
                        >
                            <img
                                v-if="brand.logo"
                                class="ks-brand-pill-logo"
                                :src="brand.logo"
                                :alt="brand.label"
                                loading="lazy"
                                decoding="async"
                            />
                            <span v-else>{{ brand.label }}</span>
                        </div>
                    </template>
                </div>
            </div>
        </section>

        <!-- Manifesto (copy + links aligned with keepersport.it) -->
        <section class="ks-manifesto">
            <div class="ks-container ks-manifesto-inner">
                <h2 class="ks-manifesto-title">
                    {{ lt.manifesto_title }}
                </h2>
                <div class="ks-manifesto-body">
                    <p
                        class="ks-manifesto-p"
                        v-html="manifestoP1Rendered"
                    ></p>
                    <p
                        class="ks-manifesto-p"
                        v-html="manifestoP2Rendered"
                    ></p>
                </div>
            </div>
        </section>

    </div>
</template>

<script>
import axios from "axios";
import { api } from "@/axiosUser";
import {
    KS_HOME_MEDIA,
    KS_SHOP_TECH_URL,
    KS_MANIFESTO_PATHS,
} from "@/constants/keepersportHomeMedia.js";
import {
    LANDING_COPY,
    resolveManifestoHtml,
} from "@/constants/landingI18n.js";
import { formatWebsiteCurrency } from "@/utils/westernNumerals";
import { formatWebsitePriceHtml, pricePromoHtml } from "@/utils/websiteCurrencyDisplay";
import { normalizeSocialHref } from "@/utils/siteSocial.js";
import { isNarrowViewport, watchNarrowViewport } from "@/utils/narrowViewport.js";
import { prefetchCatalogProductBySlug } from "@/utils/catalogApi";

function normalizeBootCoverUrl(value) {
    const url = typeof value === "string" ? value.trim() : "";
    return url !== "" ? url : null;
}

/** صور الكوفر من HTML bootstrap حتى لا تظهر صورة CDN القديمة قبل الـ API */
function bootstrapCoverFields() {
    const settings =
        typeof window !== "undefined" && window.__SITE_SETTINGS__
            ? window.__SITE_SETTINGS__
            : null;
    if (!settings || typeof settings !== "object") {
        return {
            coverImage: null,
            coverImageMobile: null,
            coverLink: "",
            whiteoutImage: null,
            whiteoutImageMobile: null,
            whiteoutLink: "",
            trainingImage: null,
            trainingImageMobile: null,
            trainingLink: "",
            technicImage: null,
            technicImageMobile: null,
            technicLink: "",
            landingSectionCards: [],
            landingCategoryStrip: [],
            landingBrandSlider: [],
            landingTechnicSection: null,
            landingSliderProducts: [],
            homeSliderCtaLink: "",
            technicalSliderProducts: [],
            technicSliderCtaLink: "",
            hasBootSections: false,
        };
    }

    return {
        coverImage: normalizeBootCoverUrl(settings.cover_image),
        coverImageMobile: normalizeBootCoverUrl(settings.cover_image_mobile),
        coverLink: typeof settings.cover_link === "string" ? settings.cover_link : "",
        whiteoutImage: normalizeBootCoverUrl(settings.whiteout_image),
        whiteoutImageMobile: normalizeBootCoverUrl(settings.whiteout_image_mobile),
        whiteoutLink: typeof settings.whiteout_link === "string" ? settings.whiteout_link : "",
        trainingImage: normalizeBootCoverUrl(settings.training_image),
        trainingImageMobile: normalizeBootCoverUrl(settings.training_image_mobile),
        trainingLink: typeof settings.training_link === "string" ? settings.training_link : "",
        technicImage: normalizeBootCoverUrl(settings.technic_image),
        technicImageMobile: normalizeBootCoverUrl(settings.technic_image_mobile),
        technicLink: typeof settings.technic_link === "string" ? settings.technic_link : "",
        landingSectionCards: Array.isArray(settings.landing_section_cards)
            ? settings.landing_section_cards
            : [],
        landingCategoryStrip: Array.isArray(settings.landing_category_strip)
            ? settings.landing_category_strip
            : [],
        landingBrandSlider: Array.isArray(settings.landing_brand_slider)
            ? settings.landing_brand_slider
            : [],
        landingTechnicSection:
            settings.landing_technic_section &&
            typeof settings.landing_technic_section === "object"
                ? settings.landing_technic_section
                : null,
        landingSliderProducts: Array.isArray(settings.landing_slider?.products)
            ? settings.landing_slider.products
            : [],
        homeSliderCtaLink:
            typeof settings.landing_slider?.cta_link === "string"
                ? settings.landing_slider.cta_link
                : "",
        technicalSliderProducts: Array.isArray(settings.technical_slider?.products)
            ? settings.technical_slider.products
            : [],
        technicSliderCtaLink:
            typeof settings.technical_slider?.cta_link === "string"
                ? settings.technical_slider.cta_link
                : "",
        hasBootSections: Array.isArray(settings.landing_section_cards),
    };
}

export default {
    name: "Home",
    data() {
        const boot = bootstrapCoverFields();
        return {
            m: KS_HOME_MEDIA,
            shopTechUrl: KS_SHOP_TECH_URL,
            /** false = كوفر بدون عنوان/زر (الصورة فقط) — فعّله لاحقاً إن لزم */
            showHeroCoverText: false,
            homeSliderCtaLink: boot.homeSliderCtaLink || "",
            technicSliderCtaLink: boot.technicSliderCtaLink || "",
            landingSliderProducts: boot.landingSliderProducts || [],
            technicalSliderProducts: boot.technicalSliderProducts || [],
            coverImage: boot.coverImage,
            coverImageMobile: boot.coverImageMobile,
            coverLink: boot.coverLink,
            whiteoutImage: boot.whiteoutImage,
            whiteoutImageMobile: boot.whiteoutImageMobile,
            whiteoutLink: boot.whiteoutLink,
            trainingImage: boot.trainingImage,
            trainingImageMobile: boot.trainingImageMobile,
            trainingLink: boot.trainingLink,
            technicImage: boot.technicImage,
            technicImageMobile: boot.technicImageMobile,
            technicLink: boot.technicLink,
            landingSectionCards: boot.landingSectionCards,
            landingCategoryStrip: boot.landingCategoryStrip,
            landingBrandSlider: boot.landingBrandSlider,
            landingTechnicSection: boot.landingTechnicSection,
            narrowCoverViewport:
                typeof window !== "undefined" ? isNarrowViewport() : false,
            heroCoverLoaded: false,
            coversFetchDone: boot.hasBootSections,
            _unwatchNarrowViewport: null,
        };
    },
    computed: {
        pageLang() {
            return this.$route.params.locale === "ar" ? "ar" : "en";
        },
        siteLocale() {
            return this.$route.params.locale || "en";
        },
        newsAdidasFallbackUrl() {
            return `/${this.siteLocale}/goalkeeper-gloves`;
        },
        newsReuschFallbackUrl() {
            return `/${this.siteLocale}/shop/reusch-goalkeeper-gloves`;
        },
        lt() {
            return LANDING_COPY[this.pageLang] || LANDING_COPY.en;
        },
        teaserSocialHref() {
            const setting = this.$store.getters.getSetting || {};
            return (
                normalizeSocialHref("instagram", setting.instagram) ||
                "https://www.instagram.com/keepersport_italy/"
            );
        },
        heroCoverImageDesktop() {
            // فقط صورة الداشبورد — بدون أي CDN قديم
            return this.coverImage || "";
        },
        heroCoverImageMobile() {
            return this.coverImageMobile || this.coverImage || "";
        },
        heroCoverImageActive() {
            return this.narrowCoverViewport
                ? this.heroCoverImageMobile
                : this.heroCoverImageDesktop;
        },
        showHeroCoverShimmer() {
            // شيمر حتى تظهر صورة الداتابيز محمّلة بالكامل — لا صورة قديمة أبدًا
            if (!this.heroCoverImageActive) {
                return !this.coversFetchDone;
            }
            return !this.heroCoverLoaded;
        },
        heroLinkProps() {
            const loc = this.$route.params.locale || "en";
            return this.landingLinkProps(
                this.coverLink,
                `/${loc}/goalkeeper-gloves`
            );
        },
        homeSliderCtaProps() {
            const loc = this.$route.params.locale || "en";
            return this.landingLinkProps(
                this.homeSliderCtaLink,
                `/${loc}/goalkeeper-gloves`
            );
        },
        whiteoutSectionImageDesktop() {
            return this.whiteoutImage || "";
        },
        whiteoutSectionImageMobile() {
            return this.whiteoutImageMobile || this.whiteoutImage || "";
        },
        whiteoutSectionImageActive() {
            return this.narrowCoverViewport
                ? this.whiteoutSectionImageMobile
                : this.whiteoutSectionImageDesktop;
        },
        whiteoutLinkProps() {
            const loc = this.$route.params.locale || "en";
            return this.landingLinkProps(
                this.whiteoutLink,
                `/${loc}/shop/keepersport-goalkeeper-gloves`
            );
        },
        trainingSectionImageDesktop() {
            return this.trainingImage || "";
        },
        trainingSectionImageMobile() {
            return this.trainingImageMobile || this.trainingImage || "";
        },
        trainingSectionImageActive() {
            return this.narrowCoverViewport
                ? this.trainingSectionImageMobile
                : this.trainingSectionImageDesktop;
        },
        trainingSectionLink() {
            const loc = this.$route.params.locale || "en";
            return this.trainingLink || `/${loc}/goalkeeper-equipment`;
        },
        technicSectionImageDesktop() {
            return this.technicImage || "";
        },
        technicSectionImageMobile() {
            return this.technicImageMobile || this.technicImage || "";
        },
        technicSectionImageActive() {
            return this.narrowCoverViewport
                ? this.technicSectionImageMobile
                : this.technicSectionImageDesktop;
        },
        technicCoverLinkProps() {
            return this.landingLinkProps(
                this.technicLink,
                `/${this.pageLang}/goalkeeper-apparel`
            );
        },
        technicTitleWhite() {
            const row = this.landingTechnicSection || {};
            return this.pageLang === "ar"
                ? row.title_white_ar || this.lt.technic_title_white
                : row.title_white_en || this.lt.technic_title_white;
        },
        technicTitleGold() {
            const row = this.landingTechnicSection || {};
            return this.pageLang === "ar"
                ? row.title_gold_ar || this.lt.technic_title_gold
                : row.title_gold_en || this.lt.technic_title_gold;
        },
        technicDesc() {
            const row = this.landingTechnicSection || {};
            return this.pageLang === "ar"
                ? row.description_ar || this.lt.technic_desc
                : row.description_en || this.lt.technic_desc;
        },
        technicSliderCtaProps() {
            return this.landingLinkProps(
                this.technicSliderCtaLink,
                `/${this.pageLang}/goalkeeper-apparel`
            );
        },
        technicSliderCards() {
            const discountFromNums = (oldVal, curVal) => {
                const o = Number(oldVal);
                const c = Number(curVal);
                if (!Number.isFinite(o) || !Number.isFinite(c) || o <= c || o <= 0) {
                    return null;
                }
                return Math.round(((o - c) / o) * 100);
            };
            if (this.technicalSliderProducts.length > 0) {
                return this.technicalSliderProducts.map((row) => ({
                    title: row.name,
                    img: row.image,
                    priceWas: row.price_old
                        ? this.formatPrice(row.price_old, row.currency)
                        : null,
                    priceNow: this.formatPromoPrice(row.price_current, row.currency),
                    brand: row.brand || "KEEPERsport",
                    productPath: `/${this.siteLocale}/product/${row.slug}`,
                    discountPct: discountFromNums(row.price_old, row.price_current),
                }));
            }
            return [];
        },
        dealOfWeekUrl() {
            const loc = this.$route.params.locale || "en";
            return `/${loc}/sale`;
        },
        megaSaleUrl() {
            const loc = this.$route.params.locale || "en";
            return `/${loc}/sale`;
        },
        categorySlides() {
            const locale = this.$route.params.locale || "en";

            if (this.landingCategoryStrip.length > 0) {
                return this.landingCategoryStrip
                    .map((row) => {
                        const label =
                            this.pageLang === "ar"
                                ? row.title_ar || row.title_en
                                : row.title_en || row.title_ar;
                        const linkProps = this.resolveLandingLink(row.link, `/${locale}/goalkeeper-gloves`);

                        return {
                            label: label || "",
                            img: row.image || "",
                            href: linkProps.href,
                            external: linkProps.external,
                            to: linkProps.to,
                        };
                    })
                    .filter((row) => row.img || row.label);
            }

            // لا نعرض صور CDN القديمة — انتظر بيانات الداشبورد فقط
            return [];
        },
        brandSlides() {
            const locale = this.siteLocale;
            const mapRow = (row) => {
                const label =
                    this.pageLang === "ar"
                        ? row.title_ar || row.title_en
                        : row.title_en || row.title_ar;
                const rawLink = String(row.link || "").trim();
                const hasLink = rawLink !== "";
                let href = "";
                let external = false;
                let to = null;
                if (hasLink) {
                    const linkProps = this.resolveLandingLink(rawLink);
                    href = linkProps.href;
                    external = linkProps.external;
                    to = linkProps.to;
                }
                return {
                    id: row.id,
                    label: label || "",
                    logo: row.image || "",
                    hasLink,
                    href,
                    external,
                    to,
                };
            };

            if (this.landingBrandSlider.length > 0) {
                return this.landingBrandSlider
                    .map(mapRow)
                    .filter((row) => row.logo || row.label);
            }

            // لا نعرض شعارات محلية قديمة قبل بيانات الداشبورد
            return [];
        },
        uhlsportPlanetSliderProducts() {
            const discountFromNums = (oldVal, curVal) => {
                const o = Number(oldVal);
                const c = Number(curVal);
                if (!Number.isFinite(o) || !Number.isFinite(c) || o <= c || o <= 0) {
                    return null;
                }
                return Math.round(((o - c) / o) * 100);
            };
            if (this.landingSliderProducts.length > 0) {
                return this.landingSliderProducts.map((row) => ({
                    title: row.name,
                    img: row.image,
                    priceWas: row.price_old
                        ? this.formatPrice(row.price_old, row.currency)
                        : null,
                    priceNow: this.formatPromoPrice(row.price_current, row.currency),
                    brand: row.brand || "KEEPERsport",
                    productPath: `/${this.siteLocale}/product/${row.slug}`,
                    discountPct: discountFromNums(row.price_old, row.price_current),
                }));
            }
            // لا نعرض منتجات CDN القديمة — فقط ما في الداشبورد
            return [];
        },
        manifestoUrls() {
            const loc = this.$route.params.locale || "en";
            return Object.fromEntries(
                Object.entries(KS_MANIFESTO_PATHS).map(([key, path]) => [
                    key,
                    `/${loc}${path}`,
                ])
            );
        },
        manifestoUrlTokens() {
            const u = this.manifestoUrls;
            return {
                __gloves__: u.gloves,
                __cut_neg__: u.cutNegative,
                __cut_reg__: u.cutRegular,
                __cut_roll__: u.cutRollFinger,
                __cut_hyb__: u.cutHybrid,
                __gloves_stay__: u.glovesWithStays,
                __varan__: u.varan,
                __glove_guide__: u.gloveGuide,
                __shoes__: u.shoes,
                __textiles__: u.textiles,
                __jerseys__: u.jerseys,
                __pants__: u.pants,
                __underwear__: u.underwear,
                __keeperdummy__: u.keeperdummy,
            };
        },
        manifestoP1Rendered() {
            return resolveManifestoHtml(
                this.lt.manifesto_p1_html,
                this.manifestoUrlTokens
            );
        },
        manifestoP2Rendered() {
            return resolveManifestoHtml(
                this.lt.manifesto_p2_html,
                this.manifestoUrlTokens
            );
        },
    },
    watch: {
        heroCoverImageActive(next, prev) {
            if (next !== prev) {
                this.heroCoverLoaded = false;
            }
        },
        narrowCoverViewport() {
            this.heroCoverLoaded = false;
        },
    },
    mounted() {
        this.syncNarrowCoverViewport();
        this._unwatchNarrowViewport = watchNarrowViewport((narrow) => {
            this.narrowCoverViewport = narrow;
        });
        this.fetchCoverSettings();
        // إذا كانت صورة البوتستراب جاهزة مسبقًا في الكاش
        this.$nextTick(() => this.markHeroCoverIfCached());
        this.fetchLandingSliderProducts();
        this.fetchTechnicalSliderProducts();
        this._ksStripWheelHandler = (e) => {
            if (
                Math.abs(e.deltaX) > Math.abs(e.deltaY) &&
                Math.abs(e.deltaX) > 0
            ) {
                e.preventDefault();
            }
        };
        const canWheelHijack = typeof window !== "undefined" && window.matchMedia?.("(hover: hover) and (pointer: fine)")?.matches;
        const wheelOpts = canWheelHijack ? { passive: false } : null;
        this.$nextTick(() => {
            const p = this.$refs.uhlsportPlanetSliderRef;
            const t = this.$refs.technicSliderRef;
            const c = this.$refs.categoryScrollRef;
            const b = this.$refs.brandScrollRef;
            if (p) {
                if (wheelOpts) {
                    p.addEventListener("wheel", this._ksStripWheelHandler, wheelOpts);
                }
                this.bindHorizontalDragScroll(p, "_ksPlanetDragCleanup");
            }
            if (t) {
                if (wheelOpts) {
                    t.addEventListener("wheel", this._ksStripWheelHandler, wheelOpts);
                }
                this.bindHorizontalDragScroll(t, "_ksTechnicDragCleanup");
            }
            if (c) {
                if (wheelOpts) {
                    c.addEventListener("wheel", this._ksStripWheelHandler, wheelOpts);
                }
                this.bindHorizontalDragScroll(c, "_ksCategoryDragCleanup");
            }
            if (b && wheelOpts) {
                b.addEventListener("wheel", this._ksStripWheelHandler, wheelOpts);
            }
        });
    },
    beforeUnmount() {
        if (typeof this._unwatchNarrowViewport === "function") {
            this._unwatchNarrowViewport();
            this._unwatchNarrowViewport = null;
        }
        const h = this._ksStripWheelHandler;
        const p = this.$refs.uhlsportPlanetSliderRef;
        const t = this.$refs.technicSliderRef;
        const c = this.$refs.categoryScrollRef;
        const b = this.$refs.brandScrollRef;
        if (h) {
            if (p) p.removeEventListener("wheel", h);
            if (t) t.removeEventListener("wheel", h);
            if (c) c.removeEventListener("wheel", h);
            if (b) b.removeEventListener("wheel", h);
        }
        if (p && this._ksPlanetDragCleanup) {
            this._ksPlanetDragCleanup();
            this._ksPlanetDragCleanup = null;
        }
        if (t && this._ksTechnicDragCleanup) {
            this._ksTechnicDragCleanup();
            this._ksTechnicDragCleanup = null;
        }
        if (c && this._ksCategoryDragCleanup) {
            this._ksCategoryDragCleanup();
            this._ksCategoryDragCleanup = null;
        }
    },
    methods: {
        prefetchLandingProduct(card) {
            const path = String(card?.productPath || "").trim();
            if (!path) {
                return;
            }
            const match = path.match(/\/product\/([^/?#]+)/i);
            const slug = match?.[1] ? decodeURIComponent(match[1]) : "";
            if (slug) {
                prefetchCatalogProductBySlug(slug);
            }
        },
        syncNarrowCoverViewport() {
            this.narrowCoverViewport = isNarrowViewport();
        },
        onHeroCoverLoaded() {
            this.heroCoverLoaded = true;
        },
        markHeroCoverIfCached() {
            const img = this.$el?.querySelector?.(".ks-hero-cover-img");
            if (img && img.complete && img.naturalWidth > 0) {
                this.heroCoverLoaded = true;
            }
        },
        normalizeCoverUrl(value) {
            const url = typeof value === "string" ? value.trim() : "";
            return url !== "" ? url : null;
        },
        landingLinkProps(link, fallback) {
            return this.resolveLandingLink(link, fallback);
        },
        resolveLandingLink(link, fallback = "") {
            const locale = this.$route.params.locale || "en";
            const raw = String(link || "").trim();
            const fb = String(fallback || "").trim();
            const chosen = raw || fb;
            if (!chosen) {
                const home = `/${locale}`;
                return { href: home, external: false, to: home };
            }
            if (/^https?:\/\//i.test(chosen)) {
                return { href: chosen, external: true, to: null };
            }
            let path = chosen.startsWith("/") ? chosen : `/${chosen}`;
            if (!/^\/(ar|en)(\/|$)/i.test(path)) {
                path = `/${locale}${path}`;
            }
            return { href: path, external: false, to: path };
        },
        async fetchCoverSettings() {
            try {
                const response = await api.get("basic/getSetting");
                const payload = response?.data?.items || {};
                const nextCover = this.normalizeCoverUrl(payload.cover_image);
                const nextCoverMobile = this.normalizeCoverUrl(payload.cover_image_mobile);
                if (
                    nextCover !== this.coverImage ||
                    nextCoverMobile !== this.coverImageMobile
                ) {
                    this.heroCoverLoaded = false;
                }
                this.coverImage = nextCover;
                this.coverImageMobile = nextCoverMobile;
                this.coverLink = payload.cover_link || "";
                this.whiteoutImage = this.normalizeCoverUrl(payload.whiteout_image);
                this.whiteoutImageMobile = this.normalizeCoverUrl(payload.whiteout_image_mobile);
                this.whiteoutLink = payload.whiteout_link || "";
                this.trainingImage = this.normalizeCoverUrl(payload.training_image);
                this.trainingImageMobile = this.normalizeCoverUrl(payload.training_image_mobile);
                this.trainingLink = payload.training_link || "";
                this.technicImage = this.normalizeCoverUrl(payload.technic_image);
                this.technicImageMobile = this.normalizeCoverUrl(payload.technic_image_mobile);
                this.technicLink = payload.technic_link || "";
                this.landingSectionCards = Array.isArray(payload.landing_section_cards)
                    ? payload.landing_section_cards
                    : [];
                this.landingCategoryStrip = Array.isArray(payload.landing_category_strip)
                    ? payload.landing_category_strip
                    : [];
                this.landingBrandSlider = Array.isArray(payload.landing_brand_slider)
                    ? payload.landing_brand_slider
                    : [];
                this.landingTechnicSection =
                    payload.landing_technic_section &&
                    typeof payload.landing_technic_section === "object"
                        ? payload.landing_technic_section
                        : null;
            } catch (error) {
                // لا تمسح صور البوتستراب إن فشل الـ API — حتى لا يومض فراغ ثم صورة
                if (!this.coverImage && !this.coverImageMobile) {
                    this.coverImage = null;
                    this.coverImageMobile = null;
                    this.coverLink = "";
                }
                if (!this.whiteoutImage && !this.whiteoutImageMobile) {
                    this.whiteoutImage = null;
                    this.whiteoutImageMobile = null;
                    this.whiteoutLink = "";
                }
                if (!this.trainingImage && !this.trainingImageMobile) {
                    this.trainingImage = null;
                    this.trainingImageMobile = null;
                    this.trainingLink = "";
                }
                if (!this.technicImage && !this.technicImageMobile) {
                    this.technicImage = null;
                    this.technicImageMobile = null;
                    this.technicLink = "";
                }
                this.landingSectionCards = [];
                this.landingCategoryStrip = [];
                this.landingBrandSlider = [];
                this.landingTechnicSection = null;
            } finally {
                this.coversFetchDone = true;
                this.$nextTick(() => this.markHeroCoverIfCached());
            }
        },
        landingCard(index) {
            return this.landingSectionCards[index] || {};
        },
        landingCardTitle(index, fallback) {
            const row = this.landingCard(index);
            return this.pageLang === "ar"
                ? row.title_ar || fallback
                : row.title_en || fallback;
        },
        formatPrice(value, currency = "SAR") {
            const amount = Number(value || 0);
            if (!Number.isFinite(amount)) return null;
            return formatWebsitePriceHtml(amount, currency, this.pageLang, {
                maximumFractionDigits: 2,
            });
        },
        formatPromoPrice(value, currency = "SAR") {
            const amount = Number(value || 0);
            if (!Number.isFinite(amount)) return null;
            return pricePromoHtml(amount, currency, this.pageLang, {
                maximumFractionDigits: 2,
            });
        },
        async fetchLandingSliderProducts() {
            try {
                const response = await api.get("basic/getLandingSliderProducts");
                const payload = response?.data?.items || {};
                if (Array.isArray(payload)) {
                    this.landingSliderProducts = payload;
                    this.homeSliderCtaLink = "";
                } else {
                    this.landingSliderProducts = Array.isArray(payload.products)
                        ? payload.products
                        : [];
                    this.homeSliderCtaLink = payload.cta_link || "";
                }
            } catch (error) {
                this.landingSliderProducts = [];
                this.homeSliderCtaLink = "";
            }
        },
        async fetchTechnicalSliderProducts() {
            try {
                const response = await api.get("basic/getTechnicalSliderProducts");
                const payload = response?.data?.items || {};
                if (Array.isArray(payload)) {
                    this.technicalSliderProducts = payload;
                    this.technicSliderCtaLink = "";
                } else {
                    this.technicalSliderProducts = Array.isArray(payload.products)
                        ? payload.products
                        : [];
                    this.technicSliderCtaLink = payload.cta_link || "";
                }
            } catch (error) {
                this.technicalSliderProducts = [];
                this.technicSliderCtaLink = "";
            }
        },
        scrollUhlsportPlanetSlider(direction) {
            this.$nextTick(() => {
                const el = this.$refs.uhlsportPlanetSliderRef;
                if (!el) return;
                const card = el.querySelector(".ks-planet-product-card");
                const gap = 10;
                const stride = card
                    ? Math.min(
                          el.clientWidth * 0.72,
                          Math.max(card.getBoundingClientRect().width + gap, 200)
                      )
                    : Math.max(240, Math.floor(el.clientWidth * 0.72));
                el.scrollBy({
                    left: direction * stride,
                    behavior: "smooth",
                });
            });
        },
        scrollTechnicSlider(direction) {
            this.$nextTick(() => {
                const el = this.$refs.technicSliderRef;
                if (!el) return;
                const card = el.querySelector(".ks-planet-product-card");
                const gap = 10;
                const stride = card
                    ? Math.min(
                          el.clientWidth * 0.72,
                          Math.max(card.getBoundingClientRect().width + gap, 200)
                      )
                    : Math.max(240, Math.floor(el.clientWidth * 0.72));
                el.scrollBy({
                    left: direction * stride,
                    behavior: "smooth",
                });
            });
        },
        /**
         * سحب أفقي بالماوس/اللمس على شريط التصنيفات (السلايدر الثاني).
         */
        bindHorizontalDragScroll(el, cleanupKey = "_ksCategoryDragCleanup") {
            if (!el || this[cleanupKey]) return;

            let activePointer = null;
            let startX = 0;
            let startScrollLeft = 0;
            let dragged = false;

            const onPointerDown = (e) => {
                if (e.pointerType !== "mouse" || e.button !== 0) return;
                if (e.target?.closest?.("a, button, [role='button']")) return;

                activePointer = e.pointerId;
                startX = e.clientX;
                startScrollLeft = el.scrollLeft;
                dragged = false;
                try {
                    el.setPointerCapture(e.pointerId);
                } catch {
                    /* ignore */
                }
            };

            const onPointerMove = (e) => {
                if (activePointer !== e.pointerId) return;
                const dx = e.clientX - startX;
                if (!dragged && Math.abs(dx) < 5) return;
                if (!dragged) {
                    dragged = true;
                    el.classList.add("ks-hscroll-dragging");
                }
                el.scrollLeft = startScrollLeft - dx;
            };

            const endPointer = (e) => {
                if (activePointer !== e.pointerId) return;
                activePointer = null;
                el.classList.remove("ks-hscroll-dragging");
                try {
                    el.releasePointerCapture(e.pointerId);
                } catch {
                    /* ignore */
                }
            };

            const onClickCapture = (e) => {
                if (!dragged) return;
                e.preventDefault();
                e.stopPropagation();
                dragged = false;
            };

            el.addEventListener("pointerdown", onPointerDown);
            el.addEventListener("pointermove", onPointerMove);
            el.addEventListener("pointerup", endPointer);
            el.addEventListener("pointercancel", endPointer);
            el.addEventListener("click", onClickCapture, true);

            this[cleanupKey] = () => {
                el.removeEventListener("pointerdown", onPointerDown);
                el.removeEventListener("pointermove", onPointerMove);
                el.removeEventListener("pointerup", endPointer);
                el.removeEventListener("pointercancel", endPointer);
                el.removeEventListener("click", onClickCapture, true);
            };
        },
        scrollCategoryStrip(direction) {
            this.$nextTick(() => {
                const el = this.$refs.categoryScrollRef;
                if (!el) return;
                const slide = el.querySelector(".ks-category-slide");
                const gap = 14;
                const stride = slide
                    ? Math.min(
                          el.clientWidth * 0.75,
                          Math.max(slide.getBoundingClientRect().width + gap, 180)
                      )
                    : Math.max(220, Math.floor(el.clientWidth * 0.75));
                el.scrollBy({
                    left: direction * stride,
                    behavior: "smooth",
                });
            });
        },
        scrollBrandStrip(direction) {
            this.$nextTick(() => {
                const el = this.$refs.brandScrollRef;
                if (!el) return;
                const pill = el.querySelector(".ks-brand-pill");
                const gap = 12;
                const stride = pill
                    ? Math.min(
                          el.clientWidth * 0.7,
                          Math.max(pill.getBoundingClientRect().width + gap, 160)
                      )
                    : Math.max(220, Math.floor(el.clientWidth * 0.7));
                el.scrollBy({
                    left: direction * stride,
                    behavior: "smooth",
                });
            });
        },
    },
};
</script>

<style scoped>

.text_color{
    color: var(--custom-highlight-color, #b89500);
}
.ks-page {
    background: #000;
    color: #e8e8e8;
}

.ks-mega-sale-lead {
    margin: 20px 0 0;
    max-width: 900px;
}

.ks-mega-sale-cta {
    margin-top: 20px;
    text-align: center;
}

.ks-deal-img-link {
    display: block;
    line-height: 0;
}

.ks-category-slider-section {
    margin-top: 24px;
    padding: 8px 0 4px;
    background: transparent;
}

.ks-category-slider-box {
    position: relative;
    padding-left: 44px;
    padding-right: 44px;
}

.ks-category-scroll {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 14px;
    width: 100%;
    min-height: 120px;
    overflow-x: auto;
    overflow-y: hidden;
    scroll-behavior: smooth;
    direction: ltr;
    padding-bottom: 0;
    margin: 0;
    outline: none;
    /* auto: يسمح بالتكبير بالقرص على iOS/Android (pan-x يمنع pinch-zoom) */
    touch-action: auto;
    overscroll-behavior-x: auto;
    -webkit-overflow-scrolling: touch;
    cursor: grab;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.ks-category-scroll.ks-hscroll-dragging {
    cursor: grabbing;
    scroll-behavior: auto;
    user-select: none;
}

.ks-category-scroll.ks-hscroll-dragging .ks-category-slide-link {
    pointer-events: none;
}

.ks-category-scroll::-webkit-scrollbar {
    display: none;
    width: 0;
    height: 0;
}

/* عدد الشرائح الظاهرة: 6 → 4 → 3 → 2 (مثل keepersport.net) */
.ks-category-slide {
    flex: 0 0 calc((100% - 70px) / 6);
    min-width: 0;
    scroll-snap-align: start;
}

@media (max-width: 1200px) {
    .ks-category-slide {
        flex: 0 0 calc((100% - 42px) / 4);
    }
}

@media (max-width: 900px) {
    .ks-category-slide {
        flex: 0 0 calc((100% - 28px) / 3);
    }
}

/* وضع «موقع سطح المكتب» على الجوال: ثبّت 3 شرائح من أول إطار (بدون وميض 4 ثم 3) */
html.ks-desktop-site-mobile .ks-category-slide {
    flex: 0 0 calc((100% - 28px) / 3) !important;
}

@media (max-width: 768px) {
    .ks-category-scroll {
        gap: 10px;
        scroll-snap-type: x mandatory;
        scroll-padding-inline: 2px;
    }

    .ks-category-slide {
        flex: 0 0 calc((100% - 10px) / 2);
    }

    .ks-category-slider-box {
        padding-left: max(34px, calc(26px + env(safe-area-inset-left, 0px)));
        padding-right: max(34px, calc(26px + env(safe-area-inset-right, 0px)));
    }

    .ks-category-slide-link img {
        aspect-ratio: 1 / 1;
        min-height: 118px;
        height: auto;
        object-fit: cover;
        object-position: center center;
    }

    .ks-category-slide-label {
        font-size: 11px;
        padding: 8px 6px;
    }
}

@media (max-width: 480px) {
    .ks-category-slide {
        flex: 0 0 calc((100% - 8px) / 2);
    }

    .ks-category-slide-link img {
        min-height: 108px;
    }
}

.ks-category-arrow {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    z-index: 2;
    width: 38px;
    height: 38px;
    padding: 0;
    border-radius: 4px;
    border: 1px solid #444;
    background: rgba(20, 20, 20, 0.92);
    color: #f5c400;
    font-size: 22px;
    line-height: 1;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.ks-category-arrow:hover {
    background: #222;
}

.ks-category-arrow--prev {
    left: 4px;
}

.ks-category-arrow--next {
    right: 4px;
}

@media (max-width: 520px) {
    .ks-category-slider-box {
        padding-left: 40px;
        padding-right: 40px;
    }

    .ks-category-arrow {
        width: 34px;
        height: 34px;
        font-size: 18px;
    }
}

.ks-category-slide-link {
    position: relative;
    display: block;
    border-radius: 0;
    overflow: hidden;
    border: none;
    background: #0f0f0f;
    line-height: 0;
    transition: opacity 0.2s;
}

.ks-category-slide-link:hover {
    opacity: 0.92;
}

.ks-category-slide-link img {
    width: 100%;
    height: auto;
    display: block;
    aspect-ratio: 1;
    object-fit: cover;
    border-radius: 0;
}

.ks-category-slide-label {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 10px 8px;
    font-size: clamp(11px, 1.1vw, 13px);
    font-weight: 700;
    line-height: 1.25;
    text-align: center;
    color: #fff;
    background: linear-gradient(
        to top,
        rgba(0, 0, 0, 0.92) 0%,
        rgba(0, 0, 0, 0.45) 55%,
        transparent 100%
    );
    white-space: normal;
}

.ks-container {
    /* max-width: 1320px; */
    margin: 0 auto;
    padding-left: 20px;
    padding-right: 20px;
}

.ks-full-img {
    display: block;
    width: 100%;
    height: auto;
    vertical-align: middle;
}

.ks-img-tight {
    margin: 0;
}

.ks-hero-img {
    position: relative;
    background: #111;
    line-height: 0;
    overflow: visible;
    min-height: clamp(180px, 42vw, 420px);
}

.ks-hero-img.is-hero-ready {
    min-height: 0;
}

.ks-hero-shimmer {
    position: absolute;
    inset: 0;
    z-index: 2;
    width: 100%;
    min-height: 100%;
    background: linear-gradient(90deg, #1a1a1a 0%, #2e2e2e 45%, #1a1a1a 90%);
    background-size: 200% 100%;
    animation: ks-hero-shimmer-move 1.15s ease-in-out infinite;
}

@keyframes ks-hero-shimmer-move {
    0% {
        background-position: 100% 0;
    }
    100% {
        background-position: -100% 0;
    }
}

.ks-hero-link-wrap {
    display: block;
    line-height: 0;
    opacity: 0;
    transition: opacity 0.18s ease;
}

.ks-hero-link-wrap--ready {
    opacity: 1;
}

.ks-hero-cover-img {
    display: block;
    width: 100%;
    height: auto;
    max-width: 100%;
    object-fit: contain;
    object-position: center top;
    vertical-align: middle;
}

.ks-hero-overlay {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: flex-end;
    padding: 24px 16px 32px;
    background: linear-gradient(
        to top,
        rgba(0, 0, 0, 0.75) 0%,
        transparent 55%
    );
    pointer-events: none;
}

.ks-hero-overlay .ks-cta {
    pointer-events: auto;
}

.ks-hero-title {
    margin: 0 0 12px;
    color: #fff;
    font-size: clamp(20px, 3vw, 32px);
    font-weight: 800;
    text-shadow: 0 1px 4px rgba(0, 0, 0, 0.5);
}

@media (max-width: 1024px) {
    .ks-hero-img {
        min-height: clamp(240px, 78vw, 560px);
    }

    .ks-hero-img.is-hero-ready {
        min-height: 0;
    }

    .ks-hero-img .ks-hero-cover-img,
    .ks-hero-img .ks-full-img,
    .ks-strip .ks-responsive-banner-img,
    .ks-training-section .ks-responsive-banner-img {
        width: 100%;
        height: auto !important;
        max-height: none !important;
        object-fit: contain !important;
        object-position: center top !important;
    }

    .ks-technic-section .ks-responsive-banner-img {
        width: 100%;
        height: auto !important;
        max-height: none !important;
        object-fit: contain !important;
        object-position: center top !important;
    }

    .ks-hero-img {
        overflow: visible;
    }

    /* سلايدر المنتجات تحت الكوفر — لا تُقصّ الصورة من الأعلى */
    .ks-planet-product-img-wrap {
        align-items: flex-start;
        overflow: visible;
        min-height: 150px;
    }

    .ks-planet-product-img-wrap img {
        max-height: none;
        width: 100%;
        height: auto;
        object-fit: contain;
        object-position: center top;
    }

    .ks-hero-overlay {
        padding: 16px 12px 18px;
        background: linear-gradient(to top, rgba(0, 0, 0, 0.72) 0%, transparent 60%);
    }

    .ks-hero-title {
        margin-bottom: 8px;
        font-size: clamp(16px, 5vw, 22px);
        text-align: center;
    }
}

/* سلايدر تحت الكوفر — عرض كامل للشاشة (بدون ks-container) */
.ks-planet-product-strip {
    --ks-gold: #e8c547;
    --ks-gold-heading: #d4af37;
    --ks-strip-bg: #000000;
    --ks-card: #111111;
    --ks-card-hover: #1a1a1a;
    --ks-card-border: #2a2a2a;
    --ks-img-well: #111111;
    --ks-text: #f5f5f5;
    --ks-text-muted: rgba(255, 255, 255, 0.55);
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
    background: var(--ks-strip-bg);
    padding: 28px 0 32px;
    border-top: 1px solid #1a1a1a;
}

.ks-planet-strip-heading {
    margin: 0 0 22px;
    padding-left: max(12px, env(safe-area-inset-left, 0px));
    padding-right: max(12px, env(safe-area-inset-right, 0px));
    text-align: center;
    font-size: clamp(15px, 2.2vw, 20px);
    font-weight: 800;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--ks-gold-heading);
    line-height: 1.35;
}

.ks-planet-product-box {
    position: relative;
    width: 100%;
    box-sizing: border-box;
    padding-left: max(44px, calc(36px + env(safe-area-inset-left, 0px)));
    padding-right: max(44px, calc(36px + env(safe-area-inset-right, 0px)));
    padding-top: 8px;
    padding-bottom: 8px;
    background: transparent;
    border-radius: 0;
    border: none;
}

.ks-planet-product-scroll {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 12px;
    width: 100%;
    min-height: 0;
    overflow-x: auto;
    overflow-y: hidden;
    scroll-behavior: smooth;
    direction: ltr;
    padding-bottom: 4px;
    margin: 0;
    outline: none;
    touch-action: auto;
    overscroll-behavior-x: auto;
    -webkit-overflow-scrolling: touch;
    cursor: grab;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.ks-planet-product-scroll.ks-hscroll-dragging {
    cursor: grabbing;
    scroll-behavior: auto;
    user-select: none;
}

.ks-planet-product-scroll.ks-hscroll-dragging .ks-planet-product-card {
    pointer-events: none;
}

.ks-planet-product-scroll::-webkit-scrollbar {
    display: none;
    width: 0;
    height: 0;
}

.ks-planet-product-card {
    flex: 0 0 calc((100% - 66px) / 6.5);
    min-width: 132px;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    padding: 12px 10px 16px;
    background: var(--ks-card);
    border: none;
    border-radius: 0;
    text-decoration: none;
    color: var(--ks-text);
    box-shadow: none;
    transition: background-color 0.2s;
}

.ks-planet-product-card:hover {
    background: var(--ks-card-hover);
}

.ks-planet-product-card:hover .ks-planet-product-img-wrap {
    background: var(--ks-card-hover);
}

.ks-planet-product-img-wrap {
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--ks-img-well);
    padding: 14px 10px;
    margin-bottom: 10px;
    min-height: 168px;
    border-radius: 0;
    overflow: hidden;
    transition: background-color 0.2s;
}

.ks-planet-product-ribbon {
    position: absolute;
    top: 10px;
    left: -28px;
    z-index: 2;
    width: 100px;
    height: 22px;
    background: #cccccc;
    color: #2b1a14;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.04em;
    line-height: 22px;
    text-align: center;
    transform: rotate(-45deg);
    transform-origin: center;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.35);
    pointer-events: none;
}

.ks-planet-product-img-wrap img {
    max-width: 100%;
    max-height: 176px;
    width: auto;
    height: auto;
    object-fit: contain;
    vertical-align: middle;
}

.ks-planet-product-brand {
    margin: 0;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0.92);
}

.ks-planet-product-title {
    margin: 6px 0 10px;
    font-size: clamp(12px, 1.35vw, 14px);
    font-weight: 700;
    line-height: 1.35;
    color: #fff;
    min-height: 2.6em;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.ks-planet-product-price {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 3px;
    margin-top: auto;
}

.ks-planet-product-price-was {
    font-size: 11px;
    color: var(--ks-text-muted);
}

.ks-planet-product-price-now {
    font-size: clamp(15px, 1.9vw, 20px);
    font-weight: 800;
    color: #fff;
    letter-spacing: 0.02em;
}

.ks-planet-product-price-now :deep(.ks-currency-icon),
.ks-planet-product-price-was :deep(.ks-currency-icon) {
    filter: brightness(0) invert(1);
    opacity: 1;
}

.ks-planet-product-price-now :deep(.ks-price-with-currency--en .ks-currency-label) {
    color: #fff;
}

.ks-planet-product-price-was :deep(.ks-currency-icon) {
    opacity: 0.72;
}

.ks-planet-product-arrow {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    z-index: 2;
    width: 44px;
    height: 44px;
    padding: 0;
    border: none;
    border-radius: 50%;
    background: #fff;
    color: #111;
    font-size: 22px;
    line-height: 1;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
    transition: background 0.2s, color 0.2s, opacity 0.2s;
}

.ks-planet-product-arrow:hover {
    background: #f0f0f0;
    color: #000;
}

.ks-planet-product-arrow--prev {
    left: max(6px, env(safe-area-inset-left, 0px));
    opacity: 0.92;
}

.ks-planet-product-arrow--next {
    right: max(6px, env(safe-area-inset-right, 0px));
}

.ks-planet-product-cta {
    text-align: center;
    margin-top: 24px;
    padding: 0 16px;
}

.ks-planet-product-strip .ks-cta--planet-slider {
    margin-top: 0;
    padding: 11px 28px;
    background: var(--ks-gold, #e8c547);
    color: #111;
    border-radius: 2px;
    font-size: 12px;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    border: none;
}

.ks-planet-product-strip .ks-cta--planet-slider:hover {
    filter: none;
    background: #f0d65a;
    color: #000;
}

@media (max-width: 1200px) {
    .ks-planet-product-card {
        flex: 0 0 calc((100% - 48px) / 4.5);
    }
}

@media (max-width: 900px) {
    .ks-planet-product-card {
        flex: 0 0 calc((100% - 36px) / 3.2);
    }
}

html.ks-desktop-site-mobile .ks-planet-product-card {
    flex: 0 0 calc((100% - 36px) / 3.2) !important;
}

@media (max-width: 768px) {
  .ks-planet-product-scroll {
    gap: 10px;
    scroll-snap-type: x mandatory;
    scroll-padding-inline: 2px;
  }

  .ks-planet-product-card {
    flex: 0 0 calc((100% - 10px) / 2);
    min-width: 0;
    scroll-snap-align: start;
    padding: 10px 8px 12px;
  }

  .ks-planet-product-img-wrap {
    width: 100%;
    min-height: 0;
    aspect-ratio: 1 / 1;
    padding: 8px;
    margin-bottom: 8px;
    background: var(--ks-img-well);
  }

  /* contain وليس cover — حتى لا تُقصّ صور المنتجات على الجوال */
  .ks-planet-product-img-wrap img {
    width: 100%;
    height: 100%;
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    object-position: center center;
  }

  .ks-planet-product-title {
    font-size: 12px;
    min-height: 2.4em;
  }

  .ks-planet-product-box {
    padding-left: max(34px, calc(26px + env(safe-area-inset-left, 0px)));
    padding-right: max(34px, calc(26px + env(safe-area-inset-right, 0px)));
  }

  .ks-planet-product-arrow {
    width: 34px;
    height: 34px;
    font-size: 17px;
  }
}

@media (max-width: 600px) {
  .ks-planet-strip-heading {
    margin-bottom: 16px;
    letter-spacing: 0.08em;
  }

  .ks-planet-product-strip {
    padding-top: 20px;
    padding-bottom: 24px;
  }

  .ks-planet-product-card {
    flex: 0 0 calc((100% - 10px) / 2);
  }

  .ks-planet-product-img-wrap {
    aspect-ratio: 1 / 0.92;
  }

  .ks-planet-product-brand {
    font-size: 10px;
  }

  .ks-planet-product-price-now {
    font-size: 15px;
  }
}

@media (max-width: 380px) {
  .ks-planet-product-card {
    flex: 0 0 calc((100% - 8px) / 2);
  }

  .ks-planet-product-img-wrap {
    aspect-ratio: 1 / 1;
  }
}

.ks-cta {
    display: inline-block;
    margin-top: 8px;
    padding: 10px 18px;
    background: #f5c400;
    color: #111;
    font-weight: 800;
    font-size: 13px;
    letter-spacing: 0.04em;
    text-decoration: none;
    border-radius: 2px;
}

.ks-cta:hover {
    filter: brightness(1.05);
}

.ks-cta--dark {
    background: #111;
    color: #f5c400;
}

.ks-deals {
    padding: 32px 0;
}

.ks-deals-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.ks-deal-card {
    border: 1px solid #333;
    padding: 24px;
    background: #111;
}

.ks-deal-card h2 {
    margin: 14px 0 0;
    font-size: 22px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: #fff;
}

.ks-deal-kicker {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #9a9a9a;
    margin: 0 0 8px;
}

.ks-deal-img {
    width: 100%;
    height: auto;
    display: block;
    margin-bottom: 0;
    border-radius: 2px;
}

.ks-deal-text {
    font-size: 15px;
    line-height: 1.55;
    margin: 0 0 16px;
    color: #c4c4c4;
}

.ks-mega-sale-lead--below-deals {
    display: block;
    margin: 44px auto 20px;
    max-width: 820px;
    text-align: center;
}

.ks-news {
    padding: 0 0 32px;
}

.ks-news-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.ks-news-card {
    border: 1px solid #333;
    padding: 24px;
    background: #111;
}

.ks-news-card h2 {
    margin: 14px 0 12px;
    font-size: 20px;
    font-weight: 800;
    text-transform: uppercase;
    color: #fff;
}

.ks-news-img {
    width: 100%;
    height: auto;
    display: block;
    margin-bottom: 0;
    border-radius: 2px;
}

.ks-strip {
    position: relative;
    background: #0a0a0a;
    margin-top: 90px;;
}

.ks-strip-cta {
    text-align: center;
    padding: 16px 0 24px;
    background: #000;
}

.ks-freddo {
    background: #000;
}

.ks-freddo-inner {
    padding: 40px 20px 36px;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.ks-freddo-text {
    color: #eaeaea;
    font-size: 15px;
    line-height: 1.6;
    max-width: 820px;
    margin: 0 auto 22px;
    text-align: center;
}

.ks-freddo-text strong {
    font-weight: 600;
    color: #fff;
}

.ks-battle-top {
    line-height: 0;
    background: #000;
}

.ks-battle {
    background: #000;
    color: #eaeaea;
    padding: 0 0 44px;
}

.ks-battle-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 36px;
}

.ks-battle-inner > p {
    font-size: 15px;
    line-height: 1.65;
    max-width: 820px;
    margin: 0 auto 18px;
    text-align: center;
}

.ks-battle-header-link {
    display: block;
    line-height: 0;
}

.ks-battle-header-img {
    width: 100%;
    height: auto;
}

.ks-battle .ks-cta {
    margin-top: 6px;
}

.ks-rule {
    border: 0;
    border-top: 1px solid #333;
    margin: 0;
}

.ks-teasers {
    background: #000;
    padding: 40px 0 44px;
}

.ks-teasers-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px 24px;
}

.ks-teaser {
    border: 1px solid #2a2a2a;
    background: #111;
    color: #fff;
    padding: 0 0 16px;
    text-align: center;
    border-radius: 2px;
    overflow: hidden;
}

.ks-teaser img {
    width: 100%;
    aspect-ratio: 1;
    object-fit: contain;
    object-position: center;
    display: block;
    background: #0a0a0a;
}

.ks-teaser h3 {
    margin: 14px 16px 8px;
    font-size: 15px;
    font-weight: 700;
}

.ks-teaser-rule {
    border: 0;
    border-top: 1px solid #444;
    margin: 0 16px 12px;
}

.ks-teaser .ks-cta {
    margin: 0 12px;
}

.ks-training-section {
    background: #000;
    padding: 8px 0 0;
}

.ks-technic-section {
    background: #000;
    color: #fff;
    padding: 0 0 8px;
}

.ks-technic-head {
    padding: 28px max(16px, env(safe-area-inset-left, 0px)) 18px
        max(16px, env(safe-area-inset-right, 0px));
    text-align: center;
}

.ks-technic-title {
    margin: 0 0 14px;
    font-size: clamp(22px, 4.5vw, 34px);
    font-weight: 900;
    letter-spacing: 0.06em;
    line-height: 1.15;
    text-transform: uppercase;
}

.ks-technic-title-white {
    color: #fff;
}

.ks-technic-title-gold {
    color: #efc527;
    margin-inline-start: 0.35em;
}

.ks-technic-desc {
    margin: 0 auto;
    max-width: 920px;
    font-size: clamp(13px, 2.2vw, 15px);
    line-height: 1.55;
    color: rgba(255, 255, 255, 0.88);
}

.ks-technic-cover-link {
    display: block;
    line-height: 0;
}

.ks-technic-strip {
    border-top: none;
    padding-top: 8px;
}

.ks-technic-cta {
    padding-bottom: 28px;
}

.ks-training {
    text-align: center;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    margin: 0 0 10px;
    padding-top: 28px;
    color: #9a9a9a;
}

.ks-training-link {
    display: block;
    line-height: 0;
}

.ks-brand-slider {
    background: #000;
    padding: 18px 0 24px;
    margin-top: 0;
    border-bottom: 1px solid #fff;
}

.ks-brand-slider-box {
    position: relative;
    width: 100%;
    box-sizing: border-box;
    padding-left: max(42px, calc(28px + env(safe-area-inset-left, 0px)));
    padding-right: max(42px, calc(28px + env(safe-area-inset-right, 0px)));
}

.ks-brand-scroll {
    display: flex;
    flex-wrap: nowrap;
    gap: 12px;
    overflow-x: auto;
    overflow-y: hidden;
    scroll-behavior: smooth;
    scrollbar-width: none;
    -ms-overflow-style: none;
    touch-action: auto;
    overscroll-behavior-x: auto;
    padding: 0;
    margin: 0;
}

.ks-brand-scroll::-webkit-scrollbar {
    display: none;
    width: 0;
    height: 0;
}

.ks-brand-pill {
    flex: 0 0 auto;
    min-width: 360px;
    min-height: 0;
    padding: 8px 18px;
    border: none;
    background: transparent;
    color: inherit;
    font-size: 16px;
    font-weight: 800;
    letter-spacing: 0.02em;
    text-transform: uppercase;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    white-space: nowrap;
    border-radius: 0;
}

.ks-brand-pill-logo {
    display: block;
    max-width: 100%;
    width: auto;
    height: 328px;
    object-fit: contain;
    filter: saturate(0.95) contrast(1.04);
}

.ks-brand-pill--static {
    cursor: default;
    pointer-events: none;
}

.ks-brand-arrow {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    z-index: 2;
    width: 38px;
    height: 38px;
    border: none;
    border-radius: 50%;
    background: #fff;
    color: #111;
    font-size: 20px;
    font-weight: 700;
    line-height: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}

.ks-brand-arrow--prev {
    left: max(6px, env(safe-area-inset-left, 0px));
}

.ks-brand-arrow--next {
    right: max(6px, env(safe-area-inset-right, 0px));
}

.ks-manifesto {
    background: #000;
    padding: 44px 0 52px;
}

.ks-manifesto-inner {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    max-width: 820px;
    margin: 0 auto;
}

.ks-manifesto-title {
    font-size: clamp(18px, 2.2vw, 24px);
    font-weight: 700;
    margin: 0 0 18px;
    line-height: 1.3;
    text-align: center;
    color: #fff;
    letter-spacing: 0.01em;
}

.ks-manifesto-body {
    width: 100%;
}

.ks-manifesto-p {
    font-size: 15px;
    line-height: 1.75;
    color: #fff;
    margin: 0 0 1.35em;
    text-align: center;
}

.ks-manifesto-body,
.ks-manifesto-body :deep(*) {
    color: #fff;
}

.ks-manifesto-p:last-child {
    margin-bottom: 0;
}

.ks-manifesto-a {
    color: #fff;
    font-weight: 400;
    text-decoration: none;
}

.ks-manifesto-a:hover,
.ks-manifesto-a:visited,
.ks-manifesto-a:active,
.ks-manifesto-a:focus {
    color: #fff;
}

@media (max-width: 700px) {
    .ks-brand-pill {
        min-width: 140px;
        padding: 6px 10px;
        font-size: 13px;
    }

    .ks-brand-slider-box {
        padding-left: max(34px, calc(20px + env(safe-area-inset-left, 0px)));
        padding-right: max(34px, calc(20px + env(safe-area-inset-right, 0px)));
    }

    .ks-brand-arrow {
        width: 32px;
        height: 32px;
        font-size: 16px;
    }

    .ks-brand-pill-logo {
        height: clamp(40px, 14vw, 88px);
    }
}

.ks-newsletter {
    background: #f5c400;
    padding: 8px 0;
    border-top: 0;
    border-bottom: 0;
}

.ks-newsletter-inner {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.ks-newsletter-tag {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 18px;
    padding: 0 6px;
    color: #000;
    font-size: 11px;
    line-height: 1;
    border-radius: 2px;
    white-space: nowrap;
}

.ks-newsletter-form {
    display: flex;
    flex-wrap: nowrap;
    gap: 6px;
    width: min(100%, 640px);
    justify-content: center;
    margin: 0 auto;
}

.ks-newsletter-form input {
    flex: 1 1 auto;
    min-width: 0;
    height: 30px;
    padding: 0 12px;
    border: 1px solid #1f1f1f;
    background: #111;
    color: #eee;
    font-size: 13px;
    border-radius: 0;
}

.ks-newsletter-form input::placeholder {
    color: #8f8f8f;
}

.ks-newsletter-form input:focus {
    outline: none;
    border-color: #f5c400;
    box-shadow: 0 0 0 1px #f5c400;
}

.ks-newsletter-form button {
    height: 30px;
    min-width: 200px;
    padding: 0 22px;
    background: #d9d9d9;
    color: #111;
    border: 1px solid #bdbdbd;
    font-weight: 800;
    font-size: 12px;
    letter-spacing: 0.04em;
    cursor: pointer;
    border-radius: 0;
    text-transform: uppercase;
}

.ks-newsletter-form button:hover {
    filter: brightness(1.03);
}

@media (max-width: 900px) {
    .ks-deals-grid,
    .ks-news-grid {
        grid-template-columns: 1fr;
    }

    .ks-teasers-grid {
        grid-template-columns: 1fr 1fr;
    }

    .ks-newsletter-inner {
        flex-direction: column;
        align-items: stretch;
        gap: 8px;
    }

    .ks-newsletter-tag {
        align-self: flex-start;
    }

    .ks-newsletter-form {
        width: 100%;
    }

    .ks-newsletter-form button {
        min-width: 140px;
    }
}

@media (max-width: 520px) {
    .ks-teasers-grid {
        grid-template-columns: 1fr;
    }
}
</style>

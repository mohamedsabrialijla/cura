<template>
    <footer class="ks-footer">
        <div class="ks-footer-main">
            <div class="ks-footer-inner">
                <div class="ks-footer-grid ks-footer-grid--primary">
                    <div
                        v-for="(section, sIdx) in primarySections"
                        :key="'p-' + sIdx"
                        class="ks-col"
                    >
                        <h4>{{ section.title }}</h4>
                        <ul>
                            <li v-for="(item, iIdx) in section.items" :key="iIdx">
                                <router-link
                                    v-if="item.internal"
                                    :to="footerTo(item)"
                                >{{ item.text }}</router-link>
                                <a
                                    v-else-if="item.href"
                                    :href="item.href"
                                    :target="footLinkOpensBlank(item.href) ? '_blank' : undefined"
                                    :rel="footLinkOpensBlank(item.href) ? 'noopener' : undefined"
                                >{{ item.text }}</a>
                                <strong v-else-if="item.strong">{{ item.text }}</strong>
                                <span v-else>{{ item.text }}</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div
                    v-if="secondarySections.length"
                    class="ks-footer-grid ks-footer-grid--secondary"
                >
                    <div
                        v-for="(section, sIdx) in secondarySections"
                        :key="'s-' + sIdx"
                        class="ks-col"
                    >
                        <h4>{{ section.title }}</h4>
                        <ul>
                            <li v-for="(item, iIdx) in section.items" :key="iIdx">
                                <router-link
                                    v-if="item.internal"
                                    :to="footerTo(item)"
                                >{{ item.text }}</router-link>
                                <a
                                    v-else-if="item.href"
                                    :href="item.href"
                                    :target="footLinkOpensBlank(item.href) ? '_blank' : undefined"
                                    :rel="footLinkOpensBlank(item.href) ? 'noopener' : undefined"
                                >{{ item.text }}</a>
                                <strong v-else-if="item.strong">{{ item.text }}</strong>
                                <span v-else>{{ item.text }}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <SocialIconsBar variant="footer" />
            </div>
        </div>
        <div class="ks-footer-bottom">
            <div class="ks-footer-inner ks-footer-bottom-inner">
                <p class="ks-copy">
                    {{ ft.copyright }}
                </p>
                <ul class="ks-pay-icons" aria-label="Payment methods">
                    <li v-for="method in paymentIconMethods" :key="method.key">
                        <img
                            :src="method.src"
                            :alt="method.label"
                            :title="method.label"
                            width="48"
                            height="32"
                            loading="lazy"
                        />
                    </li>
                </ul>
                <div class="ks-legal">
                    <router-link :to="`/${locale}/terms`">{{ ft.terms }}</router-link>
                    <router-link :to="`/${locale}/usage-return`">{{ ft.usage_return }}</router-link>
                    <router-link :to="`/${locale}/privacy`">{{ ft.privacy }}</router-link>
                    <span class="ks-country">{{ ft.country }}</span>
                </div>
            </div>
        </div>
    </footer>
</template>

<script>
import { FOOTER_I18N } from "@/constants/siteChromeI18n.js";
import { resolveSiteContactFromStore, telHref, mailtoHref, normalizeWhatsappHref } from "@/utils/siteContact.js";
import SocialIconsBar from "@/components/Website/common/SocialIconsBar.vue";

const CONTACT_SECTION_TITLES = new Set(["Contact", "التواصل"]);
/** مخفية مؤقتاً — الأقسام ما زالت في i18n لإعادتها لاحقاً */
const HIDDEN_FOOTER_SECTION_TITLES = new Set([
    "Highlights",
    "الأبرز",
    "Categories",
    "الفئات",
    "Brands",
    "العلامات التجارية",
]);

const PAYMENT_ICON_METHODS = [
    { key: "visa", label: "Visa", src: "/assets_website/payment/visa.svg" },
    { key: "mastercard", label: "Mastercard", src: "/assets_website/payment/mastercard.svg" },
    { key: "mada", label: "mada", src: "/assets_website/payment/mada.svg" },
    { key: "apple-pay", label: "Apple Pay", src: "/assets_website/payment/apple-pay.svg" },
];

export default {
    name: "FooterWebsite",
    components: {
        SocialIconsBar,
    },
    computed: {
        locale() {
            return this.$route.params.locale || "en";
        },
        pageLang() {
            return this.locale === "ar" ? "ar" : "en";
        },
        ft() {
            return FOOTER_I18N[this.pageLang] || FOOTER_I18N.en;
        },
        paymentIconMethods() {
            return PAYMENT_ICON_METHODS;
        },
        contactInfo() {
            return resolveSiteContactFromStore(this.$store);
        },
        sections() {
            const contact = this.contactInfo;
            return (this.ft.sections || [])
                .filter((section) => !HIDDEN_FOOTER_SECTION_TITLES.has(section.title))
                .map((section) => {
                if (!CONTACT_SECTION_TITLES.has(section.title)) {
                    return section;
                }
                const items = [...(section.items || [])].map((item) => {
                    if (item.href === "#" && contact.whatsapp) {
                        return {
                            ...item,
                            href: normalizeWhatsappHref(contact.whatsapp),
                        };
                    }
                    return item;
                });
                contact.mobiles.forEach((phone) => {
                    items.push({ text: phone, href: telHref(phone) });
                });
                contact.emails.forEach((email) => {
                    items.push({ text: email, href: mailtoHref(email) });
                });
                if (contact.whatsapp) {
                    const hasWhatsapp = items.some(
                        (item) => item.href === normalizeWhatsappHref(contact.whatsapp)
                    );
                    if (!hasWhatsapp) {
                        items.push({
                            text: this.pageLang === "ar" ? "واتساب" : "WhatsApp",
                            href: normalizeWhatsappHref(contact.whatsapp),
                        });
                    }
                }
                return { ...section, items };
            });
        },
        primarySections() {
            return this.sections.slice(0, 4);
        },
        secondarySections() {
            return this.sections.slice(4);
        },
    },
    methods: {
        footerTo(item) {
            const raw = String(item?.internal || "");
            if (!raw) return `/${this.locale}`;
            const [pathPart, queryPart] = raw.split("?");
            const path = `/${this.locale}${pathPart.startsWith("/") ? pathPart : `/${pathPart}`}`;
            if (!queryPart) return path;
            const query = {};
            new URLSearchParams(queryPart).forEach((value, key) => {
                query[key] = value;
            });
            return { path, query };
        },
        footLinkOpensBlank(href) {
            return typeof href === "string" && /^https?:\/\//i.test(href);
        },
    },
};
</script>

<style scoped>
.ks-footer {
    margin-top: 0;
    background: #000;
    color: #c8c8c8;
    font-size: 13px;
    border-top: 2px solid #f5c400;
}

.ks-footer-inner {
    width: 100%;
    max-width: 1280px;
    margin: 0 auto;
    padding-left: clamp(20px, 4vw, 48px);
    padding-right: clamp(20px, 4vw, 48px);
    box-sizing: border-box;
}

.ks-footer-main {
    padding: 48px 0 40px;
}

.ks-footer-grid {
    display: grid;
    gap: 32px 28px;
}

.ks-footer-grid--primary {
    grid-template-columns: repeat(4, minmax(0, 1fr));
    margin-bottom: 36px;
}

.ks-footer-grid--secondary {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    padding-top: 8px;
    border-top: 1px solid #1f1f1f;
}

.ks-col {
    min-width: 0;
}

.ks-col h4 {
    margin: 0 0 14px;
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #f5c400;
    line-height: 1.35;
}

.ks-col ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

.ks-col li {
    margin-bottom: 8px;
    line-height: 1.5;
    color: #9a9a9a;
    overflow-wrap: anywhere;
    word-break: break-word;
}

.ks-col a {
    color: #d0d0d0;
    text-decoration: none;
    display: inline-block;
    max-width: 100%;
}

.ks-col a:hover {
    color: #f5c400;
    text-decoration: underline;
}

.ks-col strong {
    display: block;
    color: #e0e0e0;
    font-weight: 700;
    line-height: 1.45;
}

.ks-footer-bottom {
    border-top: 1px solid #2a2a2a;
    padding: 20px 0 32px;
    background: #000;
}

.ks-footer-bottom-inner {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 16px 20px;
    min-height: 40px;
}

.ks-copy {
    margin: 0;
    color: #7a7a7a;
    font-size: 12px;
    line-height: 1.55;
    flex: 1 1 200px;
    min-width: 0;
}

.ks-pay-icons {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin: 0;
    padding: 0;
    list-style: none;
    flex: 0 0 auto;
}

.ks-pay-icons li {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 32px;
    padding: 0 2px;
    pointer-events: auto;
}

.ks-pay-icons img {
    display: block;
    height: 28px;
    width: auto;
    max-width: 52px;
    object-fit: contain;
    background: #fff;
    border-radius: 4px;
}

.ks-legal {
    display: flex;
    flex-wrap: wrap;
    gap: 12px 16px;
    align-items: center;
    justify-content: flex-end;
    flex: 1 1 280px;
    min-width: 0;
}

.ks-legal a,
.ks-legal :deep(a) {
    color: #c4c4c4;
    font-size: 12px;
    text-decoration: none;
    white-space: nowrap;
    position: relative;
    z-index: 2;
    padding: 6px 2px;
    pointer-events: auto;
    cursor: pointer;
}

.ks-legal a:hover,
.ks-legal :deep(a):hover {
    color: #f5c400;
    text-decoration: underline;
}

.ks-country {
    color: #7a7a7a;
    font-size: 12px;
    white-space: nowrap;
}

@media (max-width: 1024px) {
    .ks-footer-grid--primary,
    .ks-footer-grid--secondary {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 28px 24px;
    }

    .ks-footer-grid--primary {
        margin-bottom: 28px;
    }

    .ks-footer-grid--secondary {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 640px) {
    .ks-footer-main {
        padding: 36px 0 28px;
    }

    .ks-footer-inner {
        padding-left: 20px;
        padding-right: 20px;
    }

    .ks-footer-grid--primary,
    .ks-footer-grid--secondary {
        gap: 24px 20px;
    }

    .ks-footer-grid--secondary {
        padding-top: 4px;
    }

    .ks-footer-grid--secondary .ks-col:last-child:nth-child(odd) {
        max-width: 100%;
        justify-self: stretch;
    }

    .ks-col h4 {
        font-size: 10px;
        margin-bottom: 10px;
    }

    .ks-col li {
        font-size: 12px;
        margin-bottom: 7px;
    }

    .ks-footer-bottom-inner {
        flex-direction: column;
        align-items: center;
        text-align: center;
        gap: 14px;
        padding-top: 0;
    }

    .ks-copy {
        width: 100%;
        max-width: 100%;
        text-align: center;
        order: 1;
    }

    .ks-pay-icons {
        width: 100%;
        justify-content: center;
        order: 2;
    }

    .ks-legal {
        justify-content: center;
        gap: 10px 16px;
        width: 100%;
        max-width: 100%;
        margin-inline-start: 0;
        order: 3;
    }

    .ks-legal a,
    .ks-legal :deep(a),
    .ks-country {
        white-space: normal;
    }
}

html[dir="rtl"] .ks-legal {
    justify-content: flex-start;
}

@media (min-width: 641px) {
    html[dir="rtl"] .ks-copy {
        text-align: end;
    }

    html[dir="rtl"] .ks-legal {
        justify-content: flex-start;
    }
}
</style>

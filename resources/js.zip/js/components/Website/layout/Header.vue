<template>
    <header class="ks-header">
        <div v-if="tickerVisible" class="ks-ticker" :style="tickerBarStyle">
            <p class="ks-ticker-inner">
                <router-link
                    v-if="tickerDisplay.link && !tickerDisplay.external"
                    class="ks-ticker-text"
                    :to="tickerDisplay.link"
                >
                    {{ tickerDisplay.text }}
                </router-link>
                <a
                    v-else-if="tickerDisplay.link && tickerDisplay.external"
                    class="ks-ticker-text"
                    :href="tickerDisplay.link"
                    target="_blank"
                    rel="noopener"
                >
                    {{ tickerDisplay.text }}
                </a>
                <span v-else class="ks-ticker-text">{{ tickerDisplay.text }}</span>
            </p>
        </div>
        <div class="ks-bar">
            <div class="ks-bar-inner">
                <div class="ks-bar-leading">
                    <button
                        v-if="mobileNavEnabled"
                        type="button"
                        class="ks-burger"
                        :aria-label="ht.menu"
                        @click="toggleMenu"
                    >
                        <span></span><span></span><span></span>
                    </button>
                    <router-link :to="`/${locale}/account`" class="ks-account">
                        <svg
                            class="ks-account-icon"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.35"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            aria-hidden="true"
                        >
                            <circle cx="12" cy="8" r="3.5" />
                            <path
                                d="M6 20v-0.5a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v0.5"
                            />
                        </svg>
                        <span class="ks-account-label">{{ ht.account }}</span>
                    </router-link>
                </div>
                <router-link
                    :to="homeRoute"
                    class="ks-brand"
                    :title="pageLang === 'ar' ? 'الصفحة الرئيسية' : 'Home'"
                    @click="closeMenu"
                >
                    <img
                        v-if="showHeaderLogo"
                        class="ks-brand-logo"
                        :src="headerLogo"
                        alt="KEEPERsport"
                        width="192"
                        height="192"
                        decoding="async"
                    />
                </router-link>
                <div class="ks-bar-trailing">
                    <div class="ks-bar-tools">
                        <button
                            type="button"
                            class="ks-head-icon"
                            :aria-label="ht.search"
                            :title="ht.search"
                            @click="toggleSearch"
                        >
                            <svg
                                class="ks-head-icon-svg"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.35"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                aria-hidden="true"
                            >
                                <circle cx="11" cy="11" r="6.25" />
                                <path d="M20 20 16 16" />
                            </svg>
                        </button>
                        <button
                            type="button"
                            class="ks-head-icon"
                            :aria-label="ht.cart"
                            :title="ht.cart"
                            @click="openCart"
                        >
                            <svg
                                class="ks-head-icon-svg ks-head-icon-svg--cart"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 24 24"
                                fill="currentColor"
                                aria-hidden="true"
                            >
                                <path
                                    d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2M1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2"
                                />
                            </svg>
                            <span v-if="cartCount" class="ks-cart-badge" lang="en" dir="ltr">{{ cartCount }}</span>
                        </button>
                        <button class="ks-lang" @click="switchLocale">
                            {{ otherLocale === "en" ? "EN" : "AR" }}
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <form v-if="searchOpen" class="ks-search-row" role="search" @submit.prevent="submitSearch">
            <div class="ks-search-row-inner">
                <input
                    ref="searchInput"
                    v-model.trim="searchQuery"
                    class="ks-search-input"
                    type="search"
                    name="q"
                    autocomplete="off"
                    :placeholder="ht.search"
                    :aria-label="ht.search"
                    @keydown.esc="searchOpen = false"
                />
                <button type="submit" class="ks-search-submit">{{ ht.search }}</button>
            </div>
        </form>
        <div v-show="!mobileNavEnabled" class="ks-nav-wrap">
            <nav class="ks-nav" :aria-label="ht.navigation">
                <template v-for="item in ht.nav || []" :key="item.internal || item.href">
                    <router-link
                        v-if="item.internal"
                        class="ks-nav-link"
                        :to="`/${locale}${item.internal}`"
                    >
                        {{ item.label }}
                    </router-link>
                    <a v-else class="ks-nav-link" :href="item.href" target="_blank" rel="noopener">{{ item.label }}</a>
                </template>
            </nav>
        </div>
        <Teleport v-if="mobileNavEnabled" to="body">
            <div
                v-if="menuOpen"
                class="ks-mob-nav-backdrop"
                aria-hidden="true"
                @click="closeMenu"
            ></div>
            <aside
                class="ks-mob-nav-drawer"
                :class="{ 'ks-mob-nav-drawer--open': menuOpen }"
                :dir="pageLang === 'ar' ? 'rtl' : 'ltr'"
                :aria-hidden="!menuOpen"
                :aria-label="ht.navigation"
            >
                <div
                    v-if="!mobNavStack.length"
                    ref="mobNavPanel"
                    class="ks-mob-nav-panel"
                >
                    <button
                        v-for="item in mobileNavMainItems"
                        :key="item.internal || item.href"
                        type="button"
                        class="ks-mob-nav-row"
                        :class="{ 'ks-mob-nav-row--sale': item.isSale }"
                        @click="onMobileNavMain(item)"
                    >
                        <span>{{ item.label }}</span>
                        <span
                            v-if="item.children?.length"
                            class="ks-mob-nav-chev"
                            aria-hidden="true"
                        >›</span>
                    </button>
                </div>
                <div v-else ref="mobNavPanel" class="ks-mob-nav-panel ks-mob-nav-panel--sub">
                    <button type="button" class="ks-mob-nav-back" @click="mobNavBack">
                        <span class="ks-mob-nav-back-icon" aria-hidden="true">{{ mobNavBackIcon }}</span>
                        <span class="ks-mob-nav-back-title">{{ mobNavCurrentFrame.title }}</span>
                    </button>
                    <router-link
                        v-if="mobNavCurrentFrame.showAllRoute"
                        :to="mobNavCurrentFrame.showAllRoute"
                        class="ks-mob-nav-row ks-mob-nav-row--show-all"
                        @click="closeMenu"
                    >
                        <span>{{ ht.show_all }}</span>
                    </router-link>
                    <button
                        v-for="ch in mobNavCurrentChildren"
                        :key="ch._key"
                        type="button"
                        class="ks-mob-nav-row"
                        @click="onMobileNavChild(ch)"
                    >
                        <span>{{ ch.name }}</span>
                        <span
                            v-if="ch.showChevron"
                            class="ks-mob-nav-chev"
                            aria-hidden="true"
                        >›</span>
                    </button>
                </div>
                <nav class="ks-mob-nav-dock" :aria-label="pageLang === 'ar' ? 'تنقل سريع' : 'Quick navigation'">
                    <router-link
                        :to="homeRoute"
                        class="ks-mob-dock-item"
                        @click="closeMenu"
                    >
                        <img
                            v-if="showHeaderLogo"
                            class="ks-mob-dock-logo"
                            :src="headerLogo"
                            alt=""
                            width="26"
                            height="26"
                            decoding="async"
                        />
                        <span>{{ pageLang === "ar" ? "الرئيسية" : "Home" }}</span>
                    </router-link>
                    <a
                        v-if="liveChatHref"
                        :href="liveChatHref"
                        class="ks-mob-dock-item"
                        target="_blank"
                        rel="noopener"
                        @click="closeMenu"
                    >
                        <svg class="ks-mob-dock-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                            <path d="M20 2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z" />
                        </svg>
                        <span>{{ pageLang === "ar" ? "دردشة مباشرة" : "Live Chat" }}</span>
                    </a>
                    <button
                        v-else
                        type="button"
                        class="ks-mob-dock-item"
                        @click="closeMenu"
                    >
                        <svg class="ks-mob-dock-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                            <path d="M20 2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z" />
                        </svg>
                        <span>{{ pageLang === "ar" ? "دردشة مباشرة" : "Live Chat" }}</span>
                    </button>
                    <button type="button" class="ks-mob-dock-item" @click="openCartFromDock">
                        <svg class="ks-mob-dock-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                            <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2M1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2" />
                        </svg>
                        <span>{{ ht.cart }}</span>
                    </button>
                    <router-link
                        :to="`/${locale}/account`"
                        class="ks-mob-dock-item"
                        @click="closeMenu"
                    >
                        <svg class="ks-mob-dock-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" aria-hidden="true">
                            <circle cx="12" cy="8" r="3.5" />
                            <path d="M6 20v-0.5a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v0.5" />
                        </svg>
                        <span>{{ ht.account }}</span>
                    </router-link>
                </nav>
            </aside>
        </Teleport>
        <Teleport to="body">
            <div v-if="cartOpen" class="ks-cart-backdrop" @click="closeCart"></div>
            <aside class="ks-cart-drawer" :class="{ 'ks-cart-drawer--open': cartOpen }">
                <div class="ks-cart-head">
                    <h3>{{ pageLang === "ar" ? "السلة" : "Cart" }}</h3>
                    <button type="button" class="ks-cart-close" @click="closeCart">×</button>
                </div>

                <div v-if="!cartItems.length" class="ks-cart-empty">
                    {{ pageLang === "ar" ? "السلة فارغة." : "Your cart is empty." }}
                </div>

                <div v-else class="ks-cart-body">
                    <div class="ks-cart-items">
                        <article v-for="item in cartItems" :key="item.id" class="ks-cart-item">
                            <img
                                v-if="item.image"
                                :src="normalizeCatalogImageUrl(item.image)"
                                :alt="item.title"
                                referrerpolicy="no-referrer"
                                decoding="async"
                                loading="lazy"
                            />
                            <div class="ks-cart-item-body">
                                <h4>{{ item.title }}</h4>
                                <p v-if="item.subtitle">{{ item.subtitle }}</p>
                                <div class="ks-cart-item-row">
                                    <strong v-html="formatPriceHtml(item.price)"></strong>
                                    <div class="ks-qty">
                                        <button
                                            type="button"
                                            :disabled="item.qty <= 1"
                                            @click="changeQty(item.id, -1)"
                                        >-</button>
                                        <span lang="en" dir="ltr">{{ item.qty }}</span>
                                        <button
                                            type="button"
                                            :disabled="!canIncreaseQty(item)"
                                            @click="changeQty(item.id, 1)"
                                        >+</button>
                                    </div>
                                </div>
                                <button type="button" class="ks-remove" @click="removeItem(item.id)">
                                    {{ pageLang === "ar" ? "حذف" : "Remove" }}
                                </button>
                            </div>
                        </article>
                    </div>

                    <div class="ks-cart-foot">
                        <div class="ks-cart-total">
                            <span>{{ pageLang === "ar" ? "المجموع" : "Subtotal" }}</span>
                            <strong v-html="formatPriceHtml(cartSubtotal)"></strong>
                        </div>
                        <button type="button" class="ks-cart-view-btn" @click="goToCartPage">
                            {{ pageLang === "ar" ? "عرض السلة" : "View cart" }}
                        </button>
                    </div>
                </div>
            </aside>
        </Teleport>
    </header>
</template>

<script>
import { HEADER_I18N } from "@/constants/siteChromeI18n.js";
import {
    buildMobileNavMainItems,
    resolveMobileNavChildren,
    mobileNavChildRoute,
} from "@/constants/mobileNavTree.js";
import { fetchCatalogCategories, invalidateCatalogCategoriesCache } from "@/utils/catalogApi.js";
import {
    getCartItems,
    saveCartItems,
    getCartCount,
    getCartSubtotal,
    syncCartToServer,
    maxQtyForCartItem,
    CART_CHANGE_EVENT,
} from "@/utils/cartStorage.js";
import { formatWebsiteCurrency } from "@/utils/westernNumerals";
import { formatWebsitePriceHtml } from "@/utils/websiteCurrencyDisplay";
import { normalizeCatalogImageUrl } from "@/utils/catalogImageUrl";
import { normalizeWhatsappHref, resolveSiteContactFromStore } from "@/utils/siteContact.js";
import { isMobileNavContext, watchMobileNavContext } from "@/utils/mobileNavContext.js";

export default {
    name: "Header",
    data() {
        return {
            menuOpen: false,
            mobileNavEnabled: false,
            mobNavStack: [],
            _unwatchMobileNav: null,
            _navCategoriesPromise: null,
            _syncMobileNavRaf: null,
            _headerResizeObs: null,
            navCategories: [],
            navCategoriesLoaded: false,
            searchOpen: false,
            searchQuery: "",
            cartOpen: false,
            cartItems: [],
        };
    },
    computed: {
        locale() {
            return this.$route.params.locale || "en";
        },
        pageLang() {
            return this.locale === "ar" ? "ar" : "en";
        },
        ht() {
            return HEADER_I18N[this.pageLang] || HEADER_I18N.en;
        },
        tickerDisplay() {
            const t = this.setting?.header_ticker;
            const ar = this.pageLang === "ar";
            const prefix = ar
                ? (t?.prefix_ar || this.ht.ticker_prefix || "")
                : (t?.prefix_en || this.ht.ticker_prefix || "");
            const cta = ar ? (t?.cta_ar || "") : (t?.cta_en || "");
            const rawLink = ar ? (t?.link_ar || "") : (t?.link_en || "");
            const link = this.normalizeTickerLink(rawLink);
            const external = /^https?:\/\//i.test(link);
            const text = [prefix, cta].filter((part) => String(part || "").trim()).join(" ").trim();
            return { prefix, cta, text, link, external };
        },
        tickerVisible() {
            const t = this.setting?.header_ticker;
            if (t && t.is_enabled === false) {
                return false;
            }
            return Boolean(String(this.tickerDisplay.text || "").trim());
        },
        tickerBarStyle() {
            const raw = String(this.setting?.header_ticker?.bg_color || "").trim();
            const bg = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(raw) ? raw : "#000000";
            return {
                backgroundColor: bg,
                color: this.tickerContrastColor(bg),
            };
        },
        setting() {
            return this.$store.getters.getSetting;
        },
        liveChatHref() {
            const whatsapp = resolveSiteContactFromStore(this.$store).whatsapp;
            return whatsapp ? normalizeWhatsappHref(whatsapp) : "";
        },
        headerLogo() {
            const logo = this.setting?.logo;
            if (typeof logo === "string" && logo.trim() !== "") {
                return logo.trim();
            }
            return "";
        },
        showHeaderLogo() {
            return this.headerLogo !== "";
        },
        homeRoute() {
            return { path: `/${this.locale}` };
        },
        otherLocale() {
            return this.locale === "en" ? "ar" : "en";
        },
        cartCount() {
            return getCartCount(this.cartItems);
        },
        cartSubtotal() {
            return getCartSubtotal(this.cartItems);
        },
        mobileNavMainItems() {
            return this.ensureUniqueChildrenByParent(buildMobileNavMainItems(this.ht.nav, {
                categories: this.navCategories,
                ar: this.pageLang === "ar",
            }));
        },
        mobNavCurrentFrame() {
            return this.mobNavStack[this.mobNavStack.length - 1] || null;
        },
        mobNavBackIcon() {
            return this.pageLang === "ar" ? "→" : "←";
        },
        mobNavCurrentChildren() {
            const frame = this.mobNavCurrentFrame;
            if (!frame) {
                return [];
            }
            return (frame.children || []).map((ch, i) => ({
                ...ch,
                _key: `${frame.mainSlug}-${ch.slug || ch.id || ch.internalPath || i}`,
                hasGrandchildren: Boolean(ch._grandchildren?.length),
                showChevron: ch.leaf !== true,
            }));
        },
    },
    watch: {
        menuOpen(open) {
            if (open) {
                this.ensureNavCategories();
                this.$nextTick(() => this.resetMobNavScroll());
            }
            document.body.classList.toggle(
                "navigation-open",
                Boolean(open) && this.mobileNavEnabled
            );
        },
        mobileNavEnabled(enabled) {
            if (!enabled) {
                this.closeMenu();
            }
        },
        mobNavStack() {
            this.$nextTick(() => this.resetMobNavScroll());
        },
        locale() {
            invalidateCatalogCategoriesCache();
            this.navCategoriesLoaded = false;
            this.navCategories = [];
            this._navCategoriesPromise = null;
            this.applyDocumentDirection(this.locale);
            if (this.mobileNavEnabled) {
                void this.ensureNavCategories();
            }
        },
        "$route.fullPath"() {
            this.syncSearchFromRoute();
        },
    },
    mounted() {
        this.applyDocumentDirection(this.locale);
        this.syncSearchFromRoute();
        if (!this.setting) {
            this.$store.dispatch("fetchSetting");
        }
        this.applyMobileNavEnabled(isMobileNavContext());
        this._unwatchMobileNav = watchMobileNavContext(() => {
            this.syncMobileNavEnabled();
        });
        this.loadCart();
        window.addEventListener(CART_CHANGE_EVENT, this.loadCart);
        this.syncHeaderStickyOffset();
        if (typeof ResizeObserver !== "undefined" && this.$el) {
            this._headerResizeObs = new ResizeObserver(() => {
                this.syncHeaderStickyOffset();
            });
            this._headerResizeObs.observe(this.$el);
        } else {
            window.addEventListener("resize", this.syncHeaderStickyOffset, { passive: true });
        }
    },
    beforeUnmount() {
        window.removeEventListener(CART_CHANGE_EVENT, this.loadCart);
        if (typeof this._unwatchMobileNav === "function") {
            this._unwatchMobileNav();
        }
        if (this._headerResizeObs) {
            this._headerResizeObs.disconnect();
            this._headerResizeObs = null;
        } else {
            window.removeEventListener("resize", this.syncHeaderStickyOffset);
        }
        if (this._syncMobileNavRaf) {
            cancelAnimationFrame(this._syncMobileNavRaf);
            this._syncMobileNavRaf = null;
        }
        document.documentElement.style.removeProperty("--ks-plp-under-header");
        document.documentElement.classList.remove("ks-touch-nav");
        document.body.classList.remove("navigation-open");
    },
    methods: {
        tickerContrastColor(hex) {
            let color = String(hex || "#000000").replace("#", "");
            if (color.length === 3) {
                color = color
                    .split("")
                    .map((ch) => ch + ch)
                    .join("");
            }
            const r = parseInt(color.slice(0, 2), 16);
            const g = parseInt(color.slice(2, 4), 16);
            const b = parseInt(color.slice(4, 6), 16);
            const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
            return luminance > 0.55 ? "#111111" : "#ffffff";
        },
        normalizeTickerLink(raw) {
            const s = String(raw || "").trim();
            if (!s) {
                return "";
            }
            if (/^https?:\/\//i.test(s)) {
                return s;
            }
            const loc = this.locale || "en";
            if (s.startsWith(`/${loc}/`) || s === `/${loc}`) {
                return s;
            }
            if (s.startsWith("/")) {
                return `/${loc}${s}`;
            }
            return `/${loc}/${s.replace(/^\/+/, "")}`;
        },
        normalizeCatalogImageUrl,
        syncHeaderStickyOffset() {
            const el = this.$el;
            if (!el || typeof el.offsetHeight !== "number") {
                return;
            }
            document.documentElement.style.setProperty(
                "--ks-plp-under-header",
                `${el.offsetHeight}px`
            );
        },
        ensureNavCategories() {
            if (this.navCategoriesLoaded) {
                return Promise.resolve(this.navCategories);
            }
            if (this._navCategoriesPromise) {
                return this._navCategoriesPromise;
            }

            this._navCategoriesPromise = fetchCatalogCategories()
                .then((categories) => {
                    this.navCategories = Array.isArray(categories) ? categories : [];
                    this.navCategoriesLoaded = true;
                    return this.navCategories;
                })
                .catch(() => {
                    this.navCategories = [];
                    this.navCategoriesLoaded = true;
                    return this.navCategories;
                })
                .finally(() => {
                    this._navCategoriesPromise = null;
                });

            return this._navCategoriesPromise;
        },
        resetMobNavScroll() {
            const panel = this.$refs.mobNavPanel;
            if (panel && typeof panel.scrollTop === "number") {
                panel.scrollTop = 0;
            }
        },
        applyDocumentDirection(loc) {
            const html = document.documentElement;
            const isAr = String(loc || "").toLowerCase() === "ar";
            html.setAttribute("translate", "no");
            html.classList.add("notranslate");
            if (isAr) {
                html.setAttribute("dir", "rtl");
                html.setAttribute("lang", "ar");
                html.style.direction = "rtl";
                document.body.classList.add("rtl");
            } else {
                html.setAttribute("dir", "ltr");
                html.setAttribute("lang", "en");
                html.style.direction = "ltr";
                document.body.classList.remove("rtl");
            }
        },
        applyMobileNavEnabled(enabled) {
            if (enabled === this.mobileNavEnabled) {
                return;
            }
            this.mobileNavEnabled = enabled;
            document.documentElement.classList.toggle("ks-touch-nav", enabled);
            if (!enabled) {
                this.closeMenu();
                return;
            }
            void this.ensureNavCategories();
        },
        syncMobileNavEnabled() {
            if (this._syncMobileNavRaf) {
                return;
            }
            this._syncMobileNavRaf = requestAnimationFrame(() => {
                this._syncMobileNavRaf = null;
                this.applyMobileNavEnabled(isMobileNavContext());
            });
        },
        toggleMenu() {
            if (!this.mobileNavEnabled) {
                return;
            }
            if (this.menuOpen) {
                this.closeMenu();
                return;
            }
            this.mobNavStack = [];
            this.menuOpen = true;
            void this.ensureNavCategories();
            this.$nextTick(() => this.resetMobNavScroll());
        },
        closeMenu() {
            this.menuOpen = false;
            this.mobNavStack = [];
        },
        mobNavBack() {
            if (this.mobNavStack.length) {
                this.mobNavStack.pop();
                this.$nextTick(() => this.resetMobNavScroll());
            }
        },
        onMobileNavMain(item) {
            if (item.children?.length) {
                this.mobNavStack.push({
                    mainSlug: item.mainSlug,
                    title: item.label,
                    showAllRoute: { path: `/${this.locale}${item.internal}` },
                    children: item.children.map((ch) => ({
                        ...ch,
                        _grandchildren: ch.children?.length ? ch.children : null,
                        leaf: Boolean(ch.leaf) || !(ch.children?.length),
                    })),
                });
                this.$nextTick(() => this.resetMobNavScroll());
                return;
            }
            if (item.internal) {
                this.$router.push(`/${this.locale}${item.internal}`);
            }
            this.closeMenu();
        },
        onMobileNavChild(ch) {
            const frame = this.mobNavStack[this.mobNavStack.length - 1];
            if (!frame) {
                return;
            }
            if (ch._grandchildren?.length) {
                this.mobNavStack.push({
                    mainSlug: frame.mainSlug,
                    title: ch.name,
                    showAllRoute: mobileNavChildRoute(this.locale, frame.mainSlug, ch),
                    children: ch._grandchildren.map((gc) => ({
                        slug: gc.slug,
                        name: gc.label || gc.name,
                        parentSlug: ch.id || ch.slug?.replace(/^teamsport\//, ""),
                        queryBrand: gc.queryBrand,
                        leaf: true,
                    })),
                });
                this.$nextTick(() => this.resetMobNavScroll());
                return;
            }
            const route = mobileNavChildRoute(this.locale, frame.mainSlug, ch);
            this.$router.push(route);
            this.closeMenu();
        },
        ensureUniqueChildrenByParent(items) {
            return (items || []).map((item) => {
                const seen = new Set();
                const uniqChildren = [];
                for (const ch of item.children || []) {
                    const key = String(ch.slug || ch.id || ch.queryBrand || "").trim().toLowerCase();
                    if (!key || seen.has(key)) {
                        continue;
                    }
                    seen.add(key);
                    uniqChildren.push(ch);
                }
                return { ...item, children: uniqChildren };
            });
        },
        openCartFromDock() {
            this.closeMenu();
            this.openCart();
        },
        loadCart() {
            this.cartItems = getCartItems();
            if (this.cartItems.length) {
                syncCartToServer(this.cartItems);
            }
        },
        persistCart() {
            saveCartItems(this.cartItems);
        },
        syncSearchFromRoute() {
            const raw = this.$route.query?.q;
            if (typeof raw === "string") {
                this.searchQuery = raw.trim();
            }
        },
        submitSearch() {
            const term = String(this.searchQuery || "").trim();
            this.searchOpen = false;
            this.closeMenu();
            const path = `/${this.locale}/search`;
            if (!term) {
                if (this.$route.path === path) {
                    return;
                }
                this.$router.push({ path });
                return;
            }
            this.$router.push({ path, query: { q: term } });
        },
        toggleSearch() {
            this.searchOpen = !this.searchOpen;
            if (this.searchOpen) {
                this.syncSearchFromRoute();
                this.$nextTick(() => {
                    this.$refs.searchInput?.focus();
                });
            }
        },
        openCart() {
            this.closeMenu();
            this.searchOpen = false;
            this.loadCart();
            this.cartOpen = true;
        },
        closeCart() {
            this.cartOpen = false;
        },
        changeQty(itemId, delta) {
            this.cartItems = this.cartItems.map((item) => {
                if (item.id !== itemId) return item;
                return { ...item, qty: maxQtyForCartItem(item, delta) };
            });
            this.persistCart();
        },
        canIncreaseQty(item) {
            if (item.maxStock == null) {
                return true;
            }
            return Number(item.qty || 0) < Number(item.maxStock);
        },
        removeItem(itemId) {
            this.cartItems = this.cartItems.filter((item) => item.id !== itemId);
            this.persistCart();
        },
        formatPrice(value) {
            return formatWebsiteCurrency(value, "SAR", { maximumFractionDigits: 2 });
        },
        formatPriceHtml(value) {
            return formatWebsitePriceHtml(value, "SAR", this.pageLang, { maximumFractionDigits: 2 });
        },
        goToCartPage() {
            this.loadCart();
            this.closeCart();
            const target = `/${this.locale}/cart`;
            if (this.$route.path === target) {
                window.dispatchEvent(new CustomEvent(CART_CHANGE_EVENT));
                return;
            }
            this.$router.push(target);
        },
        switchLocale() {
            const newLocale = this.otherLocale;
            import("@/axiosUser").then(({ setLanguage }) => {
                setLanguage(newLocale);
            });
            let currentPath = this.$route.path.replace(/^\/(en|ar)/, "");
            if (currentPath === "") currentPath = "/";
            let updatedPath = `/${newLocale}${currentPath}`;
            if (updatedPath.slice(-1) === "/")
                updatedPath = updatedPath.slice(0, -1);
            this.$router.push({ path: updatedPath, query: this.$route.query });
            this.$store.dispatch("loadTranslations", newLocale);
            localStorage.setItem("locale", newLocale);
            this.applyDocumentDirection(newLocale);
            this.closeMenu();
            this.searchOpen = false;
            this.cartOpen = false;
        },
    },
};
</script>

<style scoped>
.ks-header {
    position: relative;
    z-index: 40;
    background: #000000;
    border-bottom: 1px solid #1a1a1a;
}

.ks-ticker {
    background: #000000;
    color: #fff;
    text-align: center;
    padding: 5px 16px;
    font-family: Impact, Haettenschweiler, "Arial Narrow Bold", sans-serif;
    font-size: 1.1em;
    line-height: 1.25;
    letter-spacing: 0.02em;
}

.ks-ticker-inner {
    display: block;
    margin: 0;
    padding: 0;
    text-align: center;
}

.ks-ticker-text {
    font-family: inherit;
    font-size: inherit;
    font-weight: 400;
    color: inherit;
    text-decoration: none;
}

a.ks-ticker-text {
    color: inherit;
    text-decoration: underline;
}

a.ks-ticker-text:hover {
    text-decoration: underline;
}

.ks-bar {
    background: #000000;
    border-bottom: 1px solid #1a1a1a;
}

.ks-bar-inner {
    max-width: 1320px;
    margin: 0 auto;
    padding: 12px 20px;
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    align-items: center;
    gap: 12px;
}

.ks-bar-leading,
.ks-bar-trailing {
    display: flex;
    align-items: center;
    min-width: 0;
}

.ks-bar-leading {
    justify-self: start;
    justify-content: flex-start;
}

.ks-bar-trailing {
    justify-self: end;
    justify-content: flex-end;
}

.ks-account {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 600;
    color: #e0e0e0;
    text-decoration: none;
}

.ks-account:hover {
    color: #f5c400;
}

.ks-account-icon {
    width: 22px;
    height: 22px;
    flex-shrink: 0;
}

.ks-head-icon {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    padding: 0;
    border: none;
    border-radius: 4px;
    background: transparent;
    color: #e8e8e8;
    text-decoration: none;
    cursor: pointer;
}

.ks-cart-badge {
    position: absolute;
    top: 4px;
    right: 2px;
    min-width: 16px;
    height: 16px;
    border-radius: 999px;
    background: #efc527;
    color: #111;
    font-size: 10px;
    font-weight: 800;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0 4px;
}

.ks-head-icon:hover {
    color: #f5c400;
    background: rgba(255, 255, 255, 0.06);
}

.ks-head-icon-svg {
    width: 22px;
    height: 22px;
}

.ks-head-icon-svg--cart {
    width: 24px;
    height: 24px;
}

.ks-brand {
    justify-self: center;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    text-align: center;
    line-height: 0;
    min-width: 0;
}

.ks-brand-logo {
    height: 56px;
    width: auto;
    max-width: min(280px, 55vw);
    object-fit: contain;
    display: block;
}

.ks-bar-tools {
    display: flex;
    align-items: center;
    gap: 10px;
}

@media (max-width: 1024px) {
    .ks-bar-inner {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 10px 12px;
    }

    .ks-bar-leading,
    .ks-bar-trailing {
        flex: 0 0 auto;
        min-width: 72px;
    }

    .ks-bar-leading {
        justify-content: flex-start;
    }

    .ks-bar-trailing {
        justify-content: flex-end;
    }

    .ks-account {
        display: none;
    }

    .ks-brand {
        flex: 1 1 auto;
        justify-content: center;
        max-width: calc(100% - 144px);
    }

    .ks-brand-logo {
        height: 48px;
        max-width: min(200px, 42vw);
    }

    .ks-bar-tools {
        gap: 4px;
    }

    .ks-lang {
        padding: 6px 8px;
        font-size: 11px;
    }
}

.ks-lang {
    border: 1px solid #333;
    background: #000000;
    color: #eee;
    border-radius: 4px;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
}

.ks-burger {
    display: none;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 5px;
    width: 40px;
    height: 40px;
    border: none;
    border-radius: 0;
    background: transparent;
    color: #e8e8e8;
    cursor: pointer;
    padding: 8px;
    touch-action: manipulation;
    -webkit-tap-highlight-color: transparent;
}

.ks-burger:hover {
    color: #f5c400;
}

.ks-burger span {
    display: block;
    width: 22px;
    height: 2px;
    background: currentColor;
    border-radius: 0;
}

.ks-nav-wrap {
    width: 100%;
    max-width: none;
    margin: 0;
    padding: 8px clamp(16px, 2.5vw, 40px) 16px;
    box-sizing: border-box;
    background: #000000;
}

.ks-search-row {
    border-bottom: 1px solid #1a1a1a;
    background: #000000;
}

.ks-search-row-inner {
    max-width: 1320px;
    margin: 0 auto;
    padding: 10px 20px;
    display: flex;
    align-items: stretch;
    gap: 8px;
}

.ks-search-input {
    flex: 1 1 auto;
    min-width: 0;
    width: 100%;
    height: 38px;
    border: 1px solid #3a3a3a;
    background: #1a1a1a;
    color: #f0f0f0;
    border-radius: 4px;
    padding: 0 12px;
    font-size: 14px;
    box-sizing: border-box;
}

.ks-search-input::placeholder {
    color: #aaa;
}

.ks-search-submit {
    flex: 0 0 auto;
    height: 38px;
    padding: 0 18px;
    border: 0;
    border-radius: 4px;
    background: #f5c400;
    color: #111;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
}

.ks-search-submit:hover {
    background: #ffda1a;
}

.ks-nav {
    display: flex;
    flex-wrap: nowrap;
    align-items: stretch;
    justify-content: space-between;
    gap: 0;
    width: 100%;
}

.ks-nav a,
.ks-nav .ks-nav-link {
    flex: 1 1 0;
    min-width: 0;
    text-align: center;
    font-size: clamp(12px, 1.05vw, 16px);
    font-weight: 500;
    line-height: 1.25;
    letter-spacing: 0.01em;
    color: #e6e6e6;
    text-decoration: none;
    padding: 10px 6px;
    border-radius: 2px;
    transition: color 0.15s, background 0.15s;
}

.ks-nav a:hover,
.ks-nav .ks-nav-link:hover {
    color: #fff;
    background: rgba(255, 255, 255, 0.06);
    text-decoration: none;
}

@media (max-width: 1024px) {
    .ks-nav-wrap {
        overflow-x: auto;
        overflow-y: hidden;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: none;
    }

    .ks-nav-wrap::-webkit-scrollbar {
        display: none;
    }

    .ks-nav {
        flex-wrap: nowrap;
        justify-content: flex-start;
        gap: 4px;
        width: max-content;
        min-width: 100%;
    }

    .ks-nav a,
    .ks-nav .ks-nav-link {
        flex: 0 0 auto;
        min-width: auto;
        white-space: nowrap;
        padding-inline: 10px;
    }
}

.ks-mob-nav-backdrop {
    display: none;
}

.ks-mob-nav-drawer {
    display: none;
}

.ks-cart-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.42);
    z-index: 10050;
}

.ks-cart-drawer {
    position: fixed;
    top: 0;
    right: 0;
    width: min(420px, 92vw);
    height: 100vh;
    background: #fff;
    color: #111;
    z-index: 10051;
    transform: translateX(102%);
    transition: transform 0.22s ease;
    display: flex;
    flex-direction: column;
    min-height: 0;
}

[dir="rtl"] .ks-cart-drawer {
    right: auto;
    left: 0;
    transform: translateX(-102%);
}

.ks-cart-drawer--open {
    transform: translateX(0);
}

[dir="rtl"] .ks-cart-drawer.ks-cart-drawer--open {
    transform: translateX(0);
}

.ks-cart-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 14px;
    border-bottom: 1px solid #ececec;
}

.ks-cart-head h3 {
    margin: 0;
    font-size: 20px;
    font-weight: 800;
}

.ks-cart-close {
    border: 0;
    background: transparent;
    font-size: 28px;
    line-height: 1;
    cursor: pointer;
}

.ks-cart-empty {
    padding: 20px 14px;
    color: #666;
}

.ks-cart-body {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
}

.ks-cart-items {
    padding: 10px 12px 0;
}

.ks-cart-item {
    display: grid;
    grid-template-columns: 82px 1fr;
    gap: 10px;
    border-bottom: 1px solid #efefef;
    padding: 10px 0;
}

.ks-cart-item img {
    width: 82px;
    height: 82px;
    object-fit: cover;
    border: 1px solid #eaeaea;
}

.ks-cart-item-body h4 {
    margin: 0 0 4px;
    font-size: 14px;
}

.ks-cart-item-body p {
    margin: 0 0 6px;
    color: #666;
    font-size: 12px;
}

.ks-cart-item-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

.ks-qty {
    display: inline-flex;
    align-items: center;
    border: 1px solid #ddd;
    border-radius: 3px;
}

.ks-qty button {
    border: 0;
    background: #fafafa;
    width: 24px;
    height: 24px;
}

.ks-qty span {
    width: 24px;
    text-align: center;
    font-size: 12px;
}

.ks-remove {
    border: 0;
    background: transparent;
    color: #b42318;
    font-size: 12px;
    padding: 3px 0 0;
    cursor: pointer;
}

.ks-qty button:disabled {
    opacity: 0.45;
    cursor: not-allowed;
}

.ks-cart-foot {
    margin-top: 8px;
    border-top: 1px solid #ececec;
    padding: 12px 12px 16px;
    background: #fff;
}

.ks-cart-total {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
}

.ks-cart-view-btn {
    width: 100%;
    min-height: 40px;
    border: 0;
    background: #efc527;
    color: #111;
    font-weight: 800;
    cursor: pointer;
}

html.ks-touch-nav .ks-burger {
    display: flex;
}

html.ks-touch-nav .ks-nav-wrap {
    display: none !important;
}

html.ks-touch-nav .ks-mob-nav-backdrop,
html.ks-desktop-site-mobile .ks-mob-nav-backdrop {
    display: block;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 10060;
}

/* نفس keepersport.net: ضيّقة، من أعلى الشاشة — حتى مع «موقع سطح المكتب» (عرض ~1024) */
html.ks-touch-nav .ks-mob-nav-drawer,
html.ks-desktop-site-mobile .ks-mob-nav-drawer {
    --ks-mob-nav-bg: #000000;
    --ks-mob-nav-text: #f5f5f5;
    --ks-mob-nav-sale: #e4002b;
    --ks-mob-nav-border: #1a1a1a;
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0;
    left: 0;
    width: min(300px, 85vw);
    max-width: 85vw;
    height: 100vh;
    height: 100dvh;
    background: var(--ks-mob-nav-bg);
    color: var(--ks-mob-nav-text);
    z-index: 10061;
    transform: translateX(-104%);
    transition: transform 0.24s ease;
    will-change: transform;
    box-shadow: 4px 0 28px rgba(0, 0, 0, 0.55);
    overflow: hidden;
}

html[dir="rtl"].ks-touch-nav .ks-mob-nav-drawer,
html[dir="rtl"].ks-desktop-site-mobile .ks-mob-nav-drawer {
    left: auto;
    right: 0;
    transform: translateX(104%);
    box-shadow: -4px 0 32px rgba(0, 0, 0, 0.5);
    direction: rtl;
}

html.ks-touch-nav .ks-mob-nav-drawer[dir="rtl"],
html.ks-desktop-site-mobile .ks-mob-nav-drawer[dir="rtl"] {
    direction: rtl;
}

html.ks-touch-nav .ks-mob-nav-drawer[dir="rtl"] .ks-mob-nav-row,
html.ks-desktop-site-mobile .ks-mob-nav-drawer[dir="rtl"] .ks-mob-nav-row {
    direction: rtl;
    text-align: right;
}

html.ks-touch-nav .ks-mob-nav-drawer[dir="rtl"] .ks-mob-nav-row > span:first-child,
html.ks-desktop-site-mobile .ks-mob-nav-drawer[dir="rtl"] .ks-mob-nav-row > span:first-child {
    flex: 1 1 auto;
    min-width: 0;
    text-align: right;
}

html.ks-touch-nav .ks-mob-nav-drawer[dir="rtl"] .ks-mob-nav-back,
html.ks-desktop-site-mobile .ks-mob-nav-drawer[dir="rtl"] .ks-mob-nav-back {
    direction: rtl;
    text-align: right;
}

html.ks-touch-nav .ks-mob-nav-drawer[dir="rtl"] .ks-mob-nav-back-title,
html.ks-desktop-site-mobile .ks-mob-nav-drawer[dir="rtl"] .ks-mob-nav-back-title {
    text-align: right;
}

html.ks-touch-nav .ks-mob-nav-drawer--open,
html.ks-desktop-site-mobile .ks-mob-nav-drawer--open,
html[dir="rtl"].ks-touch-nav .ks-mob-nav-drawer.ks-mob-nav-drawer--open,
html[dir="rtl"].ks-desktop-site-mobile .ks-mob-nav-drawer.ks-mob-nav-drawer--open {
    transform: translateX(0);
}

html.ks-touch-nav .ks-mob-nav-panel,
html.ks-desktop-site-mobile .ks-mob-nav-panel {
    flex: 1 1 auto;
    min-height: 0;
    overflow-x: hidden;
    overflow-y: auto;
    overscroll-behavior: contain;
    padding: 8px 0 4px;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: thin;
    scrollbar-color: #444 transparent;
}

html.ks-touch-nav .ks-mob-nav-panel::-webkit-scrollbar,
html.ks-desktop-site-mobile .ks-mob-nav-panel::-webkit-scrollbar {
    width: 5px;
}

html.ks-touch-nav .ks-mob-nav-panel::-webkit-scrollbar-thumb,
html.ks-desktop-site-mobile .ks-mob-nav-panel::-webkit-scrollbar-thumb {
    background: #444;
    border-radius: 4px;
}

html.ks-touch-nav .ks-mob-nav-row,
html.ks-desktop-site-mobile .ks-mob-nav-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding: 13px 20px;
    border: 0;
    background: transparent;
    color: var(--ks-mob-nav-text);
    font-size: 16px;
    font-weight: 500;
    line-height: 1.35;
    letter-spacing: 0.01em;
    text-align: start;
    cursor: pointer;
    direction: inherit;
}

html[dir="rtl"].ks-touch-nav .ks-mob-nav-panel,
html[dir="rtl"].ks-desktop-site-mobile .ks-mob-nav-panel,
html[dir="rtl"].ks-touch-nav .ks-mob-nav-dock,
html[dir="rtl"].ks-desktop-site-mobile .ks-mob-nav-dock {
    direction: rtl;
    text-align: right;
}

html.ks-touch-nav .ks-mob-nav-row--sale,
html.ks-desktop-site-mobile .ks-mob-nav-row--sale {
    color: var(--ks-mob-nav-sale);
    font-weight: 600;
}

html.ks-touch-nav .ks-mob-nav-row--show-all,
html.ks-desktop-site-mobile .ks-mob-nav-row--show-all {
    font-weight: 500;
    border-bottom: 1px solid var(--ks-mob-nav-border);
}

html.ks-touch-nav .ks-mob-nav-panel--sub .ks-mob-nav-row:not(.ks-mob-nav-row--show-all),
html.ks-desktop-site-mobile .ks-mob-nav-panel--sub .ks-mob-nav-row:not(.ks-mob-nav-row--show-all) {
    padding-inline-start: 22px;
}

html.ks-touch-nav .ks-mob-nav-row:hover,
html.ks-touch-nav .ks-mob-nav-row:focus-visible,
html.ks-desktop-site-mobile .ks-mob-nav-row:hover,
html.ks-desktop-site-mobile .ks-mob-nav-row:focus-visible {
    background: rgba(255, 255, 255, 0.06);
}

html.ks-touch-nav .ks-mob-nav-chev,
html.ks-desktop-site-mobile .ks-mob-nav-chev {
    font-size: 22px;
    line-height: 1;
    opacity: 0.9;
}

html.ks-touch-nav .ks-mob-nav-back,
html.ks-desktop-site-mobile .ks-mob-nav-back {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    padding: 12px 18px 16px;
    border: 0;
    border-bottom: 1px solid var(--ks-mob-nav-border);
    background: var(--ks-mob-nav-bg);
    color: var(--ks-mob-nav-text);
    font-size: 16px;
    font-weight: 600;
    text-align: start;
    cursor: pointer;
    position: sticky;
    top: 0;
    z-index: 1;
}

html.ks-touch-nav .ks-mob-nav-back-icon,
html.ks-desktop-site-mobile .ks-mob-nav-back-icon {
    flex-shrink: 0;
    font-size: 22px;
    line-height: 1;
    opacity: 0.95;
}

html.ks-touch-nav .ks-mob-nav-back-title,
html.ks-desktop-site-mobile .ks-mob-nav-back-title {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

html.ks-touch-nav .ks-mob-nav-dock,
html.ks-desktop-site-mobile .ks-mob-nav-dock {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2px;
    flex: 0 0 auto;
    margin-top: auto;
    width: 100%;
    padding: 12px 6px max(12px, env(safe-area-inset-bottom, 0px));
    border-top: 1px solid var(--ks-mob-nav-border);
    background: var(--ks-mob-nav-bg);
}

html.ks-touch-nav .ks-mob-dock-item,
html.ks-desktop-site-mobile .ks-mob-dock-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px 4px;
    border: 0;
    background: transparent;
    color: var(--ks-mob-nav-text);
    font-size: 10px;
    font-weight: 500;
    line-height: 1.2;
    text-decoration: none;
    cursor: pointer;
}

html.ks-touch-nav .ks-mob-dock-item:hover,
html.ks-desktop-site-mobile .ks-mob-dock-item:hover {
    color: #f5c400;
}

html.ks-touch-nav .ks-mob-dock-icon,
html.ks-desktop-site-mobile .ks-mob-dock-icon {
    width: 24px;
    height: 24px;
}

html.ks-touch-nav .ks-mob-dock-logo,
html.ks-desktop-site-mobile .ks-mob-dock-logo {
    display: block;
    width: 26px;
    height: 26px;
    object-fit: contain;
    object-position: center;
    flex-shrink: 0;
}

@media (max-width: 1024px) {
    html.ks-touch-nav .ks-burger {
        display: flex;
    }

    html.ks-touch-nav .ks-nav-wrap {
        display: none !important;
    }
}

</style>

<style>
body.navigation-open {
    overflow: hidden;
}
</style>

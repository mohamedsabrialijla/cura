<template>
    <div class="keeper-app-shell">
        <HeaderWebsite v-if="!isLoginPage" />
        <main class="keeper-main">
            <router-view :key="$route.fullPath"></router-view>
        </main>
        <NewsletterBar v-if="!isLoginPage" />
        <FooterWebsite v-if="!isLoginPage" />
        <CookieConsentBanner v-if="!isLoginPage" />
    </div>
</template>

<script>
import HeaderWebsite from "./Header.vue";
import FooterWebsite from "./Footer.vue";
import NewsletterBar from "./NewsletterBar.vue";
import CookieConsentBanner from "./CookieConsentBanner.vue";
import { watchDesktopSiteViewport } from "@/utils/desktopSiteViewport.js";

export default {
    components: {
        HeaderWebsite,
        FooterWebsite,
        NewsletterBar,
        CookieConsentBanner,
    },

    mounted() {
        this.blockGoogleTranslate();
        this._unwatchDesktopViewport = watchDesktopSiteViewport();
        this.loadScript(
            "https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.3/min/tiny-slider.js"
        );
        this.loadTranslationsOnStart();
    },

    beforeUnmount() {
        if (typeof this._unwatchDesktopViewport === "function") {
            this._unwatchDesktopViewport();
        }
    },

    created() {
        const token = localStorage.getItem("authToken");
        if (token) {
            this.$store.dispatch("fetchUser").catch(() => {
                // Ignore guest/expired-token errors on public pages.
            });
        }
    },


    computed: {
        locale() {
            return this.$route.params.locale || "en";
        },

        isLoginPage() {
            return this.$route.meta.hideHeaderFooter;
        },
    },

    methods: {
        blockGoogleTranslate() {
            const html = document.documentElement;
            html.setAttribute("translate", "no");
            html.classList.add("notranslate");
            if (!document.querySelector('meta[name="google"][content="notranslate"]')) {
                const meta = document.createElement("meta");
                meta.setAttribute("name", "google");
                meta.setAttribute("content", "notranslate");
                document.head.appendChild(meta);
            }
        },

        loadTranslationsOnStart() {
            this.$store.dispatch("fetchSetting").then(() => {});
        },

        loadScript(src) {
            let script = document.createElement("script");
            script.src = src;
            script.async = true; // جعل التحميل غير متزامن لتحسين الأداء
            document.body.appendChild(script);
        },
    },
};
</script>

<style type="text/css">
.keeper-app-shell {
    min-height: 100vh;
    background: #000000;
    color: #e8e8e8;
}

.keeper-main {
    min-height: calc(100vh - 220px);
    background: #f5f5f5;
}
</style>

<style>
/* «موقع سطح المكتب» على الجوال: العرض يُضبط عبر viewport (width=1024 + initial-scale) */
html.ks-desktop-site-mobile,
html.ks-desktop-site-mobile body {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch;
}

html.ks-desktop-site-mobile #app,
html.ks-desktop-site-mobile .keeper-app-shell {
    min-width: 0;
    width: 100%;
}

html.ks-desktop-site-mobile .keeper-main {
    min-width: 0;
}

/* Hide Chrome / Google Translate bars if they still inject */
.goog-te-banner-frame,
.goog-te-gadget,
.goog-te-balloon-frame,
.goog-logo-link,
#google_translate_element,
iframe.skiptranslate,
body > .skiptranslate {
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
}
body {
    top: 0 !important;
}
</style>

import { createRouter, createWebHistory } from "vue-router";
import adminRoutes from "./adminRoutes";
// import userRoutes from './userRoutes';
import publicRoutes from "./publicRoutes";

async function syncApiLocale(locale, path) {
    if (path.includes("/dashboard")) {
        const { setLanguage } = await import("./axios");
        setLanguage(locale);
        return;
    }

    const { setLanguage } = await import("./axiosUser");
    setLanguage(locale);
}

const routes = [
    {
        path: "/dashboard/:pathMatch(.*)*",
        redirect: (to) => {
            const locale = localStorage.getItem("locale") || "en";
            const rest = to.params.pathMatch ? `/${to.params.pathMatch}` : "";
            return `/${locale}/dashboard${rest}`;
        },
    },
    {
        path: "/dashboard",
        redirect: () => `/${localStorage.getItem("locale") || "en"}/dashboard`,
    },
    {
        path: "/:locale",
        component: {
            template: "<router-view />",
        },
        children: [
            ...publicRoutes,
            ...adminRoutes,
            // ...userRoutes,
        ],
    },
    {
        path: "/",
        redirect: "/en",
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition;
        }
        if (to.hash) {
            return { el: to.hash, top: 0, behavior: "smooth" };
        }
        return { top: 0, left: 0 };
    },
});

router.afterEach((to) => {
    if (typeof window === "undefined" || to.hash) {
        return;
    }
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
});

router.beforeEach(async (to, from, next) => {
    const locale = to.params.locale || "en";

    // تحقق من اللغة
    if (!["en", "ar"].includes(locale)) {
        return next("/en");
    }

    localStorage.setItem("locale", locale);
    await syncApiLocale(locale, to.path);

    // التحقق فقط لمسارات واجهة المستخدم (app)
    const isAppRoute = to.path.includes("/app");

    if (isAppRoute && to.meta.requiresAuth) {
        const token = localStorage.getItem("authToken");
        if (!token) {
            return next({ path: `/${locale}/login` });
        }

        try {
            const { api } = await import("./axiosUser");
            const response = await api.get("check-auth", {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            if (response.status !== 200) {
                localStorage.removeItem("authToken");
                return next({ path: `/${locale}/login` });
            }
        } catch (error) {
            localStorage.removeItem("authToken");
            return next({ path: `/${locale}/login` });
        }
    }

    next();
});

export default router;
